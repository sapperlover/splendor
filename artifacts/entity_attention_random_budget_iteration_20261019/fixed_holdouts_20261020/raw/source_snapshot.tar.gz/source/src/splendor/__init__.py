"""Public, policy-safe contracts for the two-player Splendor project.

Engine-only state deliberately lives in :mod:`splendor._state` and is not
re-exported here.  Policies receive only ``DecisionRequest`` values.
"""

from importlib import import_module
from typing import TYPE_CHECKING

from .actions import (
    Action,
    BuyMarket,
    BuyReserved,
    ClaimNoble,
    Pay,
    ReserveDeck,
    ReserveMarket,
    ReturnTokens,
    TakeDistinct,
    TakePair,
)
from .actor_critic import (
    ActorCritic,
    ActorCriticConfig,
    CardEncoder,
    NobleEncoder,
    TorchDecisionBatch,
    tensorize_batch,
)
from .contracts import DecisionRequest, Observation, Policy
from .engine import GameEngine, IllegalActionError, UnsupportedRuleError
if TYPE_CHECKING:
    from .evaluation import (
        EvaluationResult,
        PolicySpec,
        baseline_policy_spec,
        evaluate_policies,
    )
from .features import (
    FEATURE_SCHEMA,
    FEATURE_SCHEMA_VERSION,
    EncodedDecision,
    EncodedDecisionBatch,
    collate_encoded_decisions,
    encode_decision,
)
from .heuristic_policy import DevelopmentPolicy, ScorePolicy
from .model import Color, DecisionPhase, GemVector, ReservationSource, Tier, TokenVector
from .neural_policy import (
    GreedyActorCriticPolicy,
    NeuralInferenceTiming,
    SamplingActorCriticPolicy,
    frozen_actor_critic_copy,
)
from .opponent_pool import (
    OpponentChoice,
    OpponentEntry,
    OpponentPool,
    load_frozen_actor_critic_checkpoint,
)
from .ppo import (
    BatchedRolloutCollector,
    PPOConfig,
    PPOTrainer,
    PPOUpdateStats,
    PolicySample,
    PolicySampler,
    PreparedRollout,
    RolloutBatch,
    RolloutCollector,
    RolloutSample,
    clipped_policy_loss,
    compute_gae,
    explained_variance,
    group_rollout_by_episode,
    normalize_advantages,
)
from .result import TerminalReason, TerminalResult
from .random_policy import RandomPolicy
from .runner import GameRun, MatchOutcome, MatchResult, RunStatus, run_match, run_random_game
from .batched_search import BatchRunStats, BatchedSearchRunner
from .search_policy import PolicyValueSearchPolicy, SearchConfig, SearchStats
from .training_env import (
    InvalidCandidateIndexError,
    LearningDecision,
    LearningEnvironment,
    LearningEnvironmentError,
    LearningEpisodeRun,
    LearningTransition,
    StaleLearningDecisionError,
    run_learning_episode,
)

_EVALUATION_EXPORTS = frozenset(
    {"EvaluationResult", "PolicySpec", "baseline_policy_spec", "evaluate_policies"}
)


def __getattr__(name: str):
    if name not in _EVALUATION_EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module = import_module(".evaluation", __name__)
    value = getattr(module, name)
    globals()[name] = value
    return value


__all__ = [
    "Action",
    "ActorCritic",
    "ActorCriticConfig",
    "BatchedRolloutCollector",
    "BuyMarket",
    "BuyReserved",
    "CardEncoder",
    "ClaimNoble",
    "Color",
    "DecisionPhase",
    "DecisionRequest",
    "DevelopmentPolicy",
    "EvaluationResult",
    "EncodedDecision",
    "EncodedDecisionBatch",
    "FEATURE_SCHEMA",
    "FEATURE_SCHEMA_VERSION",
    "GemVector",
    "GameEngine",
    "GreedyActorCriticPolicy",
    "NeuralInferenceTiming",
    "IllegalActionError",
    "InvalidCandidateIndexError",
    "LearningDecision",
    "LearningEnvironment",
    "LearningEnvironmentError",
    "LearningEpisodeRun",
    "LearningTransition",
    "Observation",
    "OpponentChoice",
    "OpponentEntry",
    "OpponentPool",
    "NobleEncoder",
    "PPOConfig",
    "PPOTrainer",
    "PPOUpdateStats",
    "Pay",
    "Policy",
    "BatchRunStats",
    "BatchedSearchRunner",
    "PolicyValueSearchPolicy",
    "PolicySample",
    "PolicySampler",
    "PolicySpec",
    "PreparedRollout",
    "RandomPolicy",
    "ReserveDeck",
    "ReserveMarket",
    "ReservationSource",
    "ReturnTokens",
    "TakeDistinct",
    "TakePair",
    "TerminalResult",
    "TerminalReason",
    "Tier",
    "TokenVector",
    "TorchDecisionBatch",
    "UnsupportedRuleError",
    "GameRun",
    "MatchOutcome",
    "MatchResult",
    "RunStatus",
    "ScorePolicy",
    "SearchConfig",
    "SearchStats",
    "SamplingActorCriticPolicy",
    "StaleLearningDecisionError",
    "RolloutBatch",
    "RolloutCollector",
    "RolloutSample",
    "baseline_policy_spec",
    "collate_encoded_decisions",
    "clipped_policy_loss",
    "compute_gae",
    "encode_decision",
    "evaluate_policies",
    "explained_variance",
    "frozen_actor_critic_copy",
    "group_rollout_by_episode",
    "load_frozen_actor_critic_checkpoint",
    "normalize_advantages",
    "run_match",
    "run_learning_episode",
    "run_random_game",
    "tensorize_batch",
]
