"""Fast and batch-cooperative MCTS self-play with v2 compact traces."""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import math
import multiprocessing as mp
import os
import resource
import subprocess
import time
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, as_completed, wait
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

import numpy as np
import torch

from .compact_trace import replay_trace
from .features import FEATURE_SCHEMA_VERSION, PHASE_ORDER, encode_decision
from .match_stepper import MatchStepper
from .mcts_policy import MCTSConfig, MCTSSearchJob, PUCTSearchPolicy
from .opponent_pool import load_frozen_actor_critic_checkpoint
from .replay import REPLAY_SCHEMA_VERSION, RULESET_ID, to_primitive
from .rng import RNG_ALGORITHM
from .search_inference import FrozenSearchInference, InferenceConfig
from .search_training import SearchBudgetRandomization
from .selfplay import TemperatureSchedule, derive_seed, label_terminal_values
from .selfplay_data import (
    DATA_SCHEMA_V2, DATA_SCHEMA_V3, STATE_FIELDS, commit_game, game_path, load_game,
    pack_game, validate_game_arrays,
)

PROTOCOL = "mcts-selfplay-v2"
SEARCH_PROTOCOL = "determinized-puct-v2-batched"
NUMERIC_VERSION = "frozen-fp32-card-merged-v1"
PROGRESS_POLL_SECONDS = 1.0


@dataclass(frozen=True, slots=True)
class ExecutionConfig:
    backend: str = "batched_cpu"
    engine_mode: str = "fast"
    workers: int = 1
    active_games_per_worker: int = 8
    max_batch_size: int = 16
    max_batch_wait_ms: float = 2.0
    torch_threads: int = 1
    precision: str = "float32"
    batch_interface: str = "legacy"
    inference_mode: str = "eager"
    actor_projection: bool = False
    candidate_buckets: tuple[int, ...] = (16, 32, 48)
    compile_mode: str | None = None
    compile_failure_policy: str = "fallback"
    native_transport: str = "reused"
    pipeline_slots: int = 1
    search_workers: int = 1
    total_active_games: int = 8
    local_microbatch: int = 8
    shared_slots: int = 2
    shared_candidate_width: int = 256
    batch_buckets: tuple[int, ...] = ()

    def __post_init__(self) -> None:
        if self.backend not in ("serial_cpu", "batched_cpu", "batched_cuda", "native_cpu", "native_cuda", "native_cuda_pool"):
            raise ValueError("unknown self-play backend")
        if self.engine_mode not in ("checked", "fast"):
            raise ValueError("engine_mode must be checked or fast")
        if self.batch_interface not in ("legacy", "native"):
            raise ValueError("batch_interface must be legacy or native")
        if self.batch_interface == "native" and not self.backend.startswith("native_"):
            raise ValueError("the native batch interface requires a native backend")
        if self.inference_mode not in ("eager", "compiled"):
            raise ValueError("inference_mode must be eager or compiled")
        if type(self.actor_projection) is not bool:
            raise ValueError("actor_projection must be bool")
        if not self.candidate_buckets or tuple(sorted(set(self.candidate_buckets))) != tuple(self.candidate_buckets):
            raise ValueError("candidate_buckets must be sorted, unique and nonempty")
        if self.compile_mode is not None and not isinstance(self.compile_mode, str):
            raise ValueError("compile_mode must be a string or None")
        if self.compile_failure_policy not in ("fallback", "fail_fast"):
            raise ValueError("compile_failure_policy must be fallback or fail_fast")
        if self.native_transport not in ("reused", "packed"):
            raise ValueError("native_transport must be reused or packed")
        if self.pipeline_slots not in (1, 2):
            raise ValueError("pipeline_slots must be 1 or 2")
        if self.pipeline_slots > 1 and (self.backend not in ("native_cuda", "native_cuda_pool") or self.batch_interface != "native"):
            raise ValueError("the two-slot pipeline requires a native CUDA backend and native batch interface")
        if self.batch_buckets or self.compile_mode == "native-cudagraph":
            InferenceConfig(mode=self.inference_mode, batch_buckets=self.batch_buckets,
                            compile_mode=self.compile_mode, native_transport=self.native_transport)
            if self.max_batch_size > self.batch_buckets[-1]:
                raise ValueError("batch_buckets must cover max_batch_size")
        if self.compile_mode == "native-cudagraph" and (self.backend not in
                ("native_cuda", "native_cuda_pool") or self.batch_interface != "native"):
            raise ValueError("native-cudagraph requires a native CUDA backend and native batch interface")
        if self.backend.startswith("native_") and self.engine_mode != "fast":
            raise ValueError("native real-game engine requires engine_mode=fast")
        if any(type(getattr(self, name)) is not int or getattr(self, name) <= 0 for name in
               ("workers", "active_games_per_worker", "max_batch_size", "torch_threads")):
            raise ValueError("workers, active games, batch size and torch threads must be positive")
        if any(type(getattr(self, name)) is not int or getattr(self, name) <= 0 for name in
               ("search_workers", "total_active_games", "local_microbatch", "shared_slots", "shared_candidate_width")):
            raise ValueError("pooled search capacities must be positive integers")
        if self.backend == "native_cuda_pool":
            if self.workers != 1 or self.batch_interface != "native" or self.native_transport != "reused":
                raise ValueError("native_cuda_pool requires workers=1, batch_interface=native and native_transport=reused")
            if self.shared_candidate_width < max(self.candidate_buckets):
                raise ValueError("shared_candidate_width must cover candidate_buckets")
        if not math.isfinite(self.max_batch_wait_ms) or self.max_batch_wait_ms < 0:
            raise ValueError("max_batch_wait_ms must be finite and nonnegative")
        if self.precision != "float32":
            raise ValueError("only float32 inference is supported")
        if self.backend in ("batched_cuda", "native_cuda"):
            if self.workers != 1:
                raise ValueError("CUDA inference uses one GPU owner; set execution.workers=1")
        if self.backend == "serial_cpu" and (self.active_games_per_worker != 1 or self.max_batch_size != 1):
            raise ValueError("serial_cpu requires active_games_per_worker=1 and max_batch_size=1")


@dataclass(frozen=True, slots=True)
class FastSelfPlayConfig:
    protocol: str
    run_id: str
    round_index: int
    checkpoint: str
    num_games: int
    seed: int
    search_config: MCTSConfig
    execution: ExecutionConfig
    add_root_noise: bool = True
    temperature_schedule: TemperatureSchedule = TemperatureSchedule()
    validation_fraction: float = 0.1
    split_seed: int = 0
    max_completed_turns: int = 400
    search_backend: str = "native"
    chance_widening: dict[str, float] | None = None
    record_search_diagnostics: bool = False
    budget_randomization: SearchBudgetRandomization | None = None

    def __post_init__(self) -> None:
        if self.protocol != PROTOCOL or not self.run_id:
            raise ValueError("invalid v2 self-play protocol or run_id")
        if any(type(getattr(self, name)) is not int or getattr(self, name) < 0 for name in
               ("round_index", "num_games", "max_completed_turns")):
            raise ValueError("round_index, num_games and max_completed_turns must be nonnegative integers")
        if type(self.seed) is not int or type(self.split_seed) is not int:
            raise ValueError("seed and split_seed must be integers")
        if self.num_games == 0 or self.max_completed_turns == 0:
            raise ValueError("num_games and max_completed_turns must be positive")
        if type(self.add_root_noise) is not bool:
            raise ValueError("add_root_noise must be bool")
        if self.budget_randomization is not None:
            self.budget_randomization.validate_search(self.search_config.simulations, self.search_config.determinizations)
        if self.search_backend not in ("native", "native_chance"):
            raise ValueError("unknown self-play search backend")
        if self.search_backend == "native_chance":
            if not self.execution.backend.startswith("native_") or self.search_config.determinizations != 1:
                raise ValueError("native_chance self-play requires a native execution backend and determinizations=1")
        if self.chance_widening is not None:
            from .native_policy import ChanceWideningConfig
            if self.search_backend != "native_chance":
                raise ValueError("chance widening requires native_chance")
            ChanceWideningConfig(**self.chance_widening)
        if type(self.record_search_diagnostics) is not bool:
            raise ValueError("record_search_diagnostics must be bool")
        if self.record_search_diagnostics and not self.execution.backend.startswith("native_"):
            raise ValueError("search diagnostics require native execution")
        if not 0 <= self.validation_fraction < 1:
            raise ValueError("validation_fraction must be in [0,1)")
        if not Path(self.checkpoint).is_file():
            raise FileNotFoundError(self.checkpoint)

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> FastSelfPlayConfig:
        return cls(
            protocol=str(raw["protocol"]), run_id=str(raw["run_id"]),
            round_index=raw["round_index"], checkpoint=str(Path(raw["checkpoint"]).resolve()),
            num_games=raw["num_games"], seed=raw["seed"],
            search_config=MCTSConfig(**raw["search_config"]),
            execution=ExecutionConfig(**raw["execution"]),
            add_root_noise=raw.get("add_root_noise", True),
            temperature_schedule=TemperatureSchedule(**raw.get("temperature_schedule", {})),
            validation_fraction=float(raw.get("validation_fraction", 0.1)),
            split_seed=raw.get("split_seed", 0),
            max_completed_turns=raw.get("max_completed_turns", 400),
            search_backend=raw.get("search_backend", "native"),
            chance_widening=raw.get("chance_widening"),
            record_search_diagnostics=raw.get("record_search_diagnostics", False),
            budget_randomization=(SearchBudgetRandomization(**raw["budget_randomization"])
                                  if raw.get("budget_randomization") is not None else None),
        )

    def to_dict(self) -> dict[str, Any]:
        raw = asdict(self)
        # Preserve existing frozen configs and resume identities at defaults.
        if self.search_backend == "native":
            raw.pop("search_backend")
        if self.chance_widening is None:
            raw.pop("chance_widening")
        if not self.record_search_diagnostics:
            raw.pop("record_search_diagnostics")
        if self.budget_randomization is None:
            raw.pop("budget_randomization")
        for name, default in (("forced_playouts", 0.0), ("policy_target_pruning", False)):
            if raw["search_config"][name] == default:
                raw["search_config"].pop(name)
        if not self.execution.batch_buckets:
            raw["execution"].pop("batch_buckets")
        if self.execution.backend != "native_cuda_pool":
            for name in ("search_workers", "total_active_games", "local_microbatch",
                         "shared_slots", "shared_candidate_width"):
                raw["execution"].pop(name)
        return raw

    @property
    def data_schema(self) -> str:
        enhanced = (self.budget_randomization is not None or self.search_config.forced_playouts > 0
                    or self.search_config.policy_target_pruning)
        return DATA_SCHEMA_V3 if enhanced else DATA_SCHEMA_V2

    def search_training(self) -> dict[str, Any]:
        return {"search_config": asdict(self.search_config), "add_root_noise": self.add_root_noise,
                "budget_randomization": (None if self.budget_randomization is None
                                         else asdict(self.budget_randomization))}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, sort_keys=True, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(path)


def _split(config: FastSelfPlayConfig, game_id: int) -> str:
    word = derive_seed(config.split_seed, config.round_index, game_id, "split")
    return "validation" if word / (1 << 64) < config.validation_fraction else "train"


def _search_seeds(config: FastSelfPlayConfig, game_id: int) -> tuple[int, int]:
    return tuple(config.search_config.seed ^ derive_seed(config.seed, config.round_index, game_id, "search_world", p) for p in (0, 1))  # type: ignore[return-value]


def build_manifest(config: FastSelfPlayConfig) -> dict[str, Any]:
    checkpoint = Path(config.checkpoint)
    checkpoint_identity = {"path": str(checkpoint), "sha256": _sha256(checkpoint)}
    native = config.execution.backend.startswith("native_")
    versions = {"data": config.data_schema, "search": "determinized-puct-native-v1" if native else SEARCH_PROTOCOL,
                "numeric": "native-cpp-fp32-v1" if native else NUMERIC_VERSION,
                "rules": RULESET_ID, "replay": REPLAY_SCHEMA_VERSION,
                "rng": "splitmix64-world-mt19937-gamma-v1" if native else RNG_ALGORITHM,
                **({"native_rules": "cpp17-native-game-v1"} if native else {}),
                "inference": config.execution.inference_mode + (
                    "-projection" if config.execution.actor_projection else "-stock"),
                "batch_interface": config.execution.batch_interface,
                **({"native_gpu_pool": "shared-slots-v1"}
                   if config.execution.backend == "native_cuda_pool" else {}),
                **({"native_gpu_layout": "row-stride-v2"}
                   if config.execution.backend == "native_cuda"
                   and config.execution.batch_interface == "native"
                   and config.execution.native_transport == "reused" else {}),
                "feature": FEATURE_SCHEMA_VERSION,
                "seed": "splendor-selfplay-seed-v1"}
    if config.search_backend == "native_chance":
        versions["search"] = ("sampled-chance-pw-puct-native-v1" if config.chance_widening is not None
                              else "sampled-chance-puct-native-v1")
        versions["rng"] = "splitmix64-mt19937-sampled-chance-v1"
    if config.data_schema == DATA_SCHEMA_V3:
        versions["search_training"] = "playout-cap-forced-pruning-v1"
    frozen = {"config": config.to_dict(), "checkpoint_identity": checkpoint_identity, "versions": versions}
    fingerprint = hashlib.sha256(json.dumps(frozen, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    repository = Path(__file__).resolve().parents[2]
    revision = subprocess.run(["git", "rev-parse", "HEAD"], cwd=repository,
                              capture_output=True, text=True, check=True).stdout.strip()
    dirty = bool(subprocess.run(["git", "status", "--porcelain"], cwd=repository,
                                capture_output=True, text=True, check=True).stdout)
    return {"protocol": PROTOCOL, "semantic_fingerprint": fingerprint, **frozen,
            "source": {"git_revision": revision, "git_dirty": dirty}}


def _sample_record(session: _GameSession, result: object) -> dict[str, Any]:
    request = session.stepper.request
    encoded = session.encoded
    if encoded is None:
        raise AssertionError("missing root encoding")
    completed = request.observation.own_completed_turns + request.observation.opponent_completed_turns
    record = {name: getattr(encoded, name).copy() for name in STATE_FIELDS}
    record.update({
        "candidate_features": encoded.candidate_features.copy(),
        "player_id": session.stepper.engine.current_player,
        "decision_index": session.stepper.decision_count,
        "phase": PHASE_ORDER.index(request.observation.phase),
        "completed_player_turns": completed,
        "chosen_candidate_index": result.chosen_candidate_index,
        "temperature": session.temperature,
        "sampling_seed": session.sampling_seed,
        "searchable": result.searchable,
        "policy_weight": float(result.searchable and not session.low_budget), "value_weight": 1.0,
        "policy_target": result.policy_target,
        "behavior_policy": result.behavior_policy,
        "root_network_prior": result.root_network_prior,
        "root_used_prior": result.root_used_prior,
        "root_visit_counts": result.root_visit_counts,
        "simulation_budgets": result.simulation_budgets,
        "per_world_root_visit_counts": result.per_world_root_visit_counts,
        "valid_world_count": len(result.simulation_budgets),
        "simulations": result.simulations,
        "max_tree_depth": result.max_tree_depth,
        "transition_cap_hits": result.transition_cap_hits,
    })
    if session.config.data_schema == DATA_SCHEMA_V3:
        record.update(low_budget=session.low_budget,
                      per_world_policy_target_counts=result.per_world_policy_target_counts,
                      per_world_root_value_sums=result.per_world_root_value_sums,
                      per_world_forced_playouts=result.per_world_forced_playouts)
    return record


@dataclass(slots=True)
class _GameSession:
    config: FastSelfPlayConfig
    game_id: int
    evaluator: FrozenSearchInference
    model_version: str = ""
    search_diagnostics: list[dict[str, Any]] = field(default_factory=list)
    started: float = field(default_factory=time.perf_counter)
    stepper: MatchStepper = field(init=False)
    policies: tuple[PUCTSearchPolicy, PUCTSearchPolicy] = field(init=False)
    records: list[dict[str, Any]] = field(default_factory=list)
    job: MCTSSearchJob | None = None
    encoded: Any = None
    temperature: float = 0.0
    sampling_seed: int = 0
    low_budget: bool = False
    job_started: float = 0.0
    decision_latencies_ms: list[float] = field(default_factory=list)
    root_encoding_seconds: float = 0.0
    real_rule_seconds: float = 0.0

    @property
    def finished(self) -> bool:
        return self.stepper.terminal is not None

    def failure_scene(self) -> dict[str, Any]:
        return {
            "game_id": self.game_id, "game_seed": self.stepper.trace["game_seed"],
            "first_player": self.stepper.trace["first_player"], "trace": self.stepper.trace,
            "root_decision_index": self.stepper.decision_count,
            "root_request": None if self.finished else to_primitive(self.stepper.request),
            "search_context": None if self.job is None else
                              to_primitive(self.job.failure_context_for_world(None)),
        }

    def __post_init__(self) -> None:
        game_seed = derive_seed(self.config.seed, self.config.round_index, self.game_id, "game")
        stepper_cls = MatchStepper
        if self.config.execution.backend.startswith("native_"):
            from .native_match_stepper import NativeMatchStepper
            stepper_cls = NativeMatchStepper
        self.stepper = stepper_cls(self.game_id, game_seed, self.game_id % 2,
                                   mode=self.config.execution.engine_mode)
        seeds = _search_seeds(self.config, self.game_id)
        policy_cls = PUCTSearchPolicy
        if self.config.execution.backend.startswith("native_"):
            from .native_policy import NativePUCTSearchPolicy, NativeChancePUCTSearchPolicy, ChanceWideningConfig
            policy_cls = NativeChancePUCTSearchPolicy if self.config.search_backend == "native_chance" else NativePUCTSearchPolicy
        policy_kwargs = {}
        if self.config.chance_widening is not None:
            policy_kwargs["chance_widening"] = ChanceWideningConfig(**self.config.chance_widening)
        self.policies = tuple(
            policy_cls(self.evaluator.model,
                             config=MCTSConfig(**(asdict(self.config.search_config) | {"seed": seeds[p]})),
                             device=self.evaluator.device,
                             **({"model_version": self.model_version} if self.config.execution.backend.startswith("native_") else
                                {"engine_mode": self.config.execution.engine_mode}),
                             evaluator=self.evaluator, **policy_kwargs)
            for p in (0, 1)
        )  # type: ignore[assignment]

    def ensure_job(self) -> None:
        while self.stepper.terminal is None and self.job is None:
            if self.stepper.completed_player_turns >= self.config.max_completed_turns:
                raise RuntimeError("engineering turn limit reached without formal terminal")
            request = self.stepper.request
            player_id = self.stepper.engine.current_player
            encoding_started = time.perf_counter()
            self.encoded = encode_decision(request)
            self.root_encoding_seconds += time.perf_counter() - encoding_started
            self.temperature = self.config.temperature_schedule.for_request(request)
            self.sampling_seed = derive_seed(
                self.config.seed, self.config.round_index, self.game_id,
                "search_sampling", player_id, self.stepper.decision_count,
            )
            randomization = self.config.budget_randomization
            self.low_budget = (len(request.legal_actions) > 1 and randomization is not None
                               and randomization.is_low(self.sampling_seed))
            policy = self.policies[player_id]
            high_config = replace(self.config.search_config, seed=policy.config.seed)
            policy.config = (replace(high_config, simulations=randomization.low_simulations,
                                     forced_playouts=0.0, policy_target_pruning=False)
                             if self.low_budget else high_config)
            self.job_started = time.perf_counter()
            self.job = policy.start_job(
                request, add_root_noise=self.config.add_root_noise and not self.low_budget,
                temperature=self.temperature, sampling_seed=self.sampling_seed,
                root_encoded=self.encoded,
            )
            if self.job.done:
                self.take_result()

    def take_result(self) -> None:
        if self.job is None or not self.job.done:
            raise RuntimeError("search result is not ready")
        result = self.job.result
        if self.config.record_search_diagnostics:
            request = self.stepper.request
            row = {"decision_index": self.stepper.decision_count,
                   "phase": PHASE_ORDER.index(request.observation.phase),
                   "completed_player_turns": request.observation.own_completed_turns + request.observation.opponent_completed_turns,
                   "max_visible_score": max(request.observation.self_public.score, request.observation.opponent_public.score),
                   "opponent_blind_reserved": sum(r.card is None for r in request.observation.opponent_public.reserved_cards),
                   "stats": dict(self.job.core.stats())}
            if self.config.search_backend == "native_chance":
                chance = dict(self.job.core.chance_diagnostics())
                row["chance"] = {k: v for k, v in chance.items() if k not in
                                 ("root_value_sums", "root_outcome_visits", "root_chance_pools")}
            self.search_diagnostics.append(row)
        self.decision_latencies_ms.append((time.perf_counter() - self.job_started) * 1000)
        record = _sample_record(self, result)
        rule_started = time.perf_counter()
        self.stepper.apply(result.chosen_candidate_index)
        self.real_rule_seconds += time.perf_counter() - rule_started
        self.records.append(record)
        self.job = None
        self.encoded = None

    def commit(self, root: Path, fingerprint: str, checkpoint_sha: str) -> dict[str, Any]:
        terminal = self.stepper.terminal
        if terminal is None:
            raise RuntimeError("cannot commit an incomplete game")
        label_terminal_values(self.records, terminal)
        metadata = {
            "data_schema": self.config.data_schema, "feature_schema_version": FEATURE_SCHEMA_VERSION,
            "semantic_fingerprint": fingerprint, "checkpoint_sha256": checkpoint_sha,
            "run_id": self.config.run_id, "round_index": self.config.round_index,
            "game_id": self.game_id, "game_seed": self.stepper.trace["game_seed"],
            "search_seeds": list(_search_seeds(self.config, self.game_id)),
            "first_player": self.stepper.trace["first_player"],
            "split": _split(self.config, self.game_id), "status": "natural_terminal",
            "terminal_result": to_primitive(terminal),
            "completed_player_turns": self.stepper.completed_player_turns,
            "decision_count": len(self.records),
            "player_decisions": [sum(r["player_id"] == p for r in self.records) for p in (0, 1)],
            "policy_samples": sum(r["policy_weight"] > 0 for r in self.records),
            "mcts_stats": [policy.stats.to_dict() | {"rule_seconds": policy.stats.rule_seconds,
                                               "native_compute_seconds": getattr(policy, "native_compute_seconds", 0.0)}
                           for policy in self.policies],
            "forced_skips": self.stepper.engine.forced_skip_count,
            "trace": self.stepper.trace,
            "collection_seconds": time.perf_counter() - self.started,
        }
        if self.config.data_schema == DATA_SCHEMA_V3:
            metadata["search_training"] = self.config.search_training()
        if self.config.record_search_diagnostics:
            metadata["search_diagnostics"] = self.search_diagnostics
        write_started = time.perf_counter()
        arrays = pack_game(self.records, metadata, self.config.search_config.determinizations)
        validate_game_arrays({name: value for name, value in arrays.items() if name != "metadata_json"},
                             metadata, expected_game_id=self.game_id, fingerprint=fingerprint,
                             simulations=self.config.search_config.simulations,
                             worlds=self.config.search_config.determinizations,
                             split=metadata["split"])
        path = commit_game(root, self.game_id, arrays)
        return {"game_id": self.game_id, "decisions": len(self.records),
                "policy_samples": metadata["policy_samples"], "bytes": path.stat().st_size,
                "simulations": sum(r["simulations"] for r in self.records),
                "write_seconds": time.perf_counter() - write_started,
                "root_encoding_seconds": self.root_encoding_seconds,
                "real_rule_seconds": self.real_rule_seconds,
                "search_rule_seconds": sum(p.stats.rule_seconds for p in self.policies),
                "native_encoding_seconds": sum(p.stats.feature_seconds for p in self.policies),
                "native_compute_seconds": sum(getattr(p, "native_compute_seconds", 0.0) for p in self.policies)}


def _committed_game_count(root: Path) -> int:
    """Count archived games without validating them; progress reporting only."""

    games_root = root / "games"
    return len(list(games_root.glob("game-*.npz"))) if games_root.is_dir() else 0


def _cpu_seconds() -> float:
    """CPU seconds (user+sys) consumed by this process so far."""

    usage = resource.getrusage(resource.RUSAGE_SELF)
    return usage.ru_utime + usage.ru_stime


def _live_snapshot(evaluator: Any, batcher: Any, sessions: Any, finished_simulations: int,
                   completed_games: int) -> dict[str, Any]:
    """Uniform live counters for one worker; benchmarks never guess internals.

    Simulations are counted when they complete inside the tree, including roots
    that are still running, and are disjoint from the completed-game total.
    Network positions count rows actually evaluated (terminal paths skip the
    network), split into root / policy / value-only rows.
    """

    stats = evaluator.stats
    snapshot: dict[str, Any] = {
        "timestamp": time.perf_counter(),
        "simulations": finished_simulations + sum(
            policy.live_simulations() for session in sessions for policy in session.policies),
        "network_positions": stats.positions,
        "physical_batches": stats.batches,
        "feature_seconds": stats.feature_seconds,
        "forward_seconds": stats.forward_seconds,
        "h2d_seconds": stats.h2d_seconds,
        "d2h_seconds": stats.d2h_seconds,
        "wait_seconds": stats.wait_seconds,
        "batch_sizes": dict(stats.batch_sizes),
        "compile_seconds": dict(stats.compile.get("compile_seconds", {})),
        "disabled_graphs": dict(stats.compile.get("disabled_graphs", {})),
        "active_games": len(sessions),
        "completed_games": completed_games,
    }
    if batcher is not None:
        snapshot.update({
            "native_batch_rows": batcher.rows,
            "native_batch_batches": batcher.batches,
            "native_wide_batches": batcher.wide_batches,
            "native_root_rows": batcher.root_rows,
            "native_policy_rows": batcher.policy_rows,
            "native_value_rows": batcher.value_rows,
            "native_inflight_batches": batcher.inflight_batches,
            "native_inflight_rows": batcher.inflight_rows,
            "native_peak_inflight_rows": batcher.peak_inflight_rows,
            "native_fill_seconds": batcher.fill_seconds,
            "native_consume_seconds": batcher.consume_seconds,
        })
    return snapshot


def _collect_group(
    config: FastSelfPlayConfig, root: Path, game_ids: tuple[int, ...],
    fingerprint: str, checkpoint_sha: str, stop_event: Any = None,
    completed_before: int = 0,
    on_game_complete: Callable[[int, int], None] | None = None,
    stat_callback: Callable[[dict[str, Any]], None] | None = None,
    evaluator: Any = None,
    window_control: Any = None,
) -> dict[str, Any]:
    """Collect one worker's share of games.

    ``stat_callback`` receives a uniform counter snapshot (see
    :func:`_live_snapshot`) once per scheduling round, so a timed window that
    ends mid-game still measures real work.  ``window_control`` optionally
    implements ``warmup_seconds``, ``ready(payload)``, ``wait_start()`` and
    ``stop_requested()``: the worker warms up on the real configuration, reports
    readiness, waits for the common start gate and stops when the control says
    so, so model loading, warm-up, measurement and the tail are separate phases
    with one shared clock rule.
    """
    initialization_started = time.perf_counter()
    torch.set_num_threads(config.execution.torch_threads)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass
    device = "cuda" if config.execution.backend in ("batched_cuda", "native_cuda") else "cpu"
    if evaluator is None:
        model = load_frozen_actor_critic_checkpoint(Path(config.checkpoint), device=device)
        evaluator = FrozenSearchInference(
            model, device=device,
            config=InferenceConfig(
                mode=config.execution.inference_mode,
                actor_projection=config.execution.actor_projection,
                candidate_buckets=config.execution.candidate_buckets,
                compile_mode=config.execution.compile_mode,
                compile_failure_policy=config.execution.compile_failure_policy,
                native_transport=config.execution.native_transport,
                batch_buckets=config.execution.batch_buckets,
            ),
        )
    native = config.execution.backend.startswith("native_")
    batcher = None
    if native and config.execution.batch_interface == "native":
        from .native_policy import NativeBatchRunner, _default_catalog
        batcher = NativeBatchRunner(
            evaluator, _default_catalog(), capacity=config.execution.max_batch_size,
            buckets=config.execution.candidate_buckets, slots=config.execution.pipeline_slots,
        )
    initialization_seconds = time.perf_counter() - initialization_started
    compile_warmup_seconds = 0.0
    if window_control is not None and window_control.warmup_seconds > 0:
        compile_warmup_seconds = evaluator.warmup_native(config.execution.candidate_buckets)
    started = time.perf_counter()
    window_cpu_started = _cpu_seconds()
    window_start_snapshot = _live_snapshot(evaluator, batcher, (), 0, 0)
    warmup_deadline: float | None = None
    if window_control is not None:
        if window_control.warmup_seconds > 0:
            warmup_deadline = started + window_control.warmup_seconds
        else:
            window_control.ready({"initialization_seconds": initialization_seconds,
                                  "warmup_seconds": 0.0,
                                  "compile_warmup_seconds": compile_warmup_seconds})
            window_control.wait_start()
            started = time.perf_counter()
            window_cpu_started = _cpu_seconds()
            window_start_snapshot = _live_snapshot(evaluator, batcher, (), 0, 0)
    todo = iter(game_ids)
    active: dict[int, _GameSession] = {}
    completed: list[dict[str, Any]] = []
    peak_active = 0
    peak_pending = 0
    failed: _GameSession | None = None
    batch_context: list[tuple[_GameSession, Any]] = []
    batch_outputs: Any = None
    active_request_id: str | None = None
    job_sessions: dict[Any, _GameSession] = {}
    in_batch = False
    decision_latencies_ms: list[float] = []
    finished_simulations = 0
    last_stat_time = 0.0
    try:
        while True:
            if window_control is not None:
                if window_control.stop_requested():
                    break
                if warmup_deadline is not None and time.perf_counter() >= warmup_deadline:
                    window_control.ready({"initialization_seconds": initialization_seconds,
                                          "warmup_seconds": time.perf_counter() - started,
                                          "compile_warmup_seconds": compile_warmup_seconds})
                    window_control.wait_start()
                    warmup_deadline = None
                    started = time.perf_counter()
                    window_cpu_started = _cpu_seconds()
                    window_start_snapshot = _live_snapshot(evaluator, batcher, active.values(),
                                                           finished_simulations, len(completed))
            elif stop_event is not None and stop_event.is_set():
                break
            while len(active) < config.execution.active_games_per_worker:
                try:
                    game_id = next(todo)
                except StopIteration:
                    break
                active[game_id] = _GameSession(config, game_id, evaluator, checkpoint_sha)
            if not active:
                break
            peak_active = max(peak_active, len(active))
            for game_id, session in tuple(active.items()):
                failed = session
                if session.job is not None and session.job.done:
                    session.take_result()
                session.ensure_job()
                if session.stepper.terminal is not None:
                    game_summary = session.commit(root, fingerprint, checkpoint_sha)
                    finished_simulations += game_summary["simulations"]
                    completed.append(game_summary)
                    decision_latencies_ms.extend(session.decision_latencies_ms)
                    del active[game_id]
                    if on_game_complete is not None:
                        on_game_complete(completed_before + len(completed), config.num_games)
            if batcher is not None:
                jobs = [session.job for session in active.values() if session.job is not None]
                jobs = [job for job in jobs if job.pending_rows(False) or job.pending_rows(True)]
                peak_pending = max(peak_pending, sum(
                    job.pending_rows(False) + job.pending_rows(True) for job in jobs))
                if not jobs:
                    if active:
                        raise RuntimeError("active games have no pending search work")
                    continue
                job_sessions = {session.job: session for session in active.values() if session.job is not None}
                in_batch = True
                batcher.run(jobs, context=job_sessions)
                in_batch = False
                failed = None
                active_request_id = None
                now = time.perf_counter()
                if stat_callback is not None and now - last_stat_time >= 0.05:
                    last_stat_time = now
                    stat_callback({"worker_id": game_ids[0],
                                   **_live_snapshot(evaluator, batcher, active.values(),
                                                    finished_simulations, len(completed))})
                continue
            pending = [(session, item) for session in active.values() if session.job is not None
                       for item in session.job.pending_requests()]
            peak_pending = max(peak_pending, len(pending))
            if not pending:
                if active:
                    raise RuntimeError("active games have no pending search work")
                continue
            for kind in ("policy_value", "value_only"):
                work = [(session, item) for session, item in pending if item.kind == kind]
                for start in range(0, len(work), config.execution.max_batch_size):
                    group = work[start:start + config.execution.max_batch_size]
                    failed = group[0][0]
                    active_request_id = group[0][1].request_id
                    batch_context = group
                    batch_outputs = None
                    requests = tuple(item.request for _, item in group) if not native else ()
                    if native and any(item.model_version != checkpoint_sha for _, item in group):
                        raise RuntimeError("native inference batch model version mismatch")
                    if kind == "policy_value":
                        encoded = tuple(item.encoded if item.encoded is not None else encode_decision(item.request)
                                        for _, item in group)
                        results = (evaluator.policy_value_encoded(encoded) if native else
                                   evaluator.policy_value(requests, encoded=encoded))
                        batch_outputs = results
                        for (session, item), (logits, value) in zip(group, results):
                            failed = session
                            active_request_id = item.request_id
                            assert session.job is not None
                            session.job.submit(item.request_id, logits, value)
                    else:
                        results = (evaluator.value_only_encoded(tuple(item.encoded for _, item in group))
                                   if native else evaluator.value_only(requests))
                        batch_outputs = results
                        for (session, item), value in zip(group, results):
                            failed = session
                            active_request_id = item.request_id
                            assert session.job is not None
                            session.job.submit(item.request_id, None, value)
                    batch_context = []
                    batch_outputs = None
                    active_request_id = None
            now = time.perf_counter()
            if stat_callback is not None and now - last_stat_time >= 0.05:
                last_stat_time = now
                stat_callback({"worker_id": game_ids[0],
                               **_live_snapshot(evaluator, batcher, active.values(),
                                                finished_simulations, len(completed))})
    except Exception as error:
        import traceback
        error_text = traceback.format_exc()
        try:
            report = None if batcher is None or not in_batch else batcher.failure_report(error)
            if report is not None and report["scope"] == "row" and report["context"] is not None:
                session = report["context"]
                entry = report["entry"]
                _atomic_json(root / "failures" / f"game-{session.game_id:06d}.json", {
                    "protocol": "search-accel-failure-v1", "scope": "row",
                    "game_id": session.game_id,
                    "game_seed": session.stepper.trace["game_seed"],
                    "first_player": session.stepper.trace["first_player"],
                    "trace": session.stepper.trace,
                    "root_decision_index": session.stepper.decision_count,
                    "root_request": to_primitive(session.stepper.request) if session.stepper.terminal is None else None,
                    "search_config": asdict(config.search_config),
                    "checkpoint_sha256": checkpoint_sha,
                    "batch_requests": [batcher.row_context(entry) | {"game_id": session.game_id,
                                                                      "state_only": report["record"]["state_only"],
                                                                      "batch": report["record"]["batch"]}],
                    "search_context": (None if session.job is None else to_primitive(
                        session.job.failure_context_for_world(None if entry.world < 0 else entry.world))),
                    "error_type": type(error).__name__, "error_detail": str(error),
                    "traceback": error_text,
                })
            elif report is not None:
                batches = report["records"]
                building = report["building"]
                context = report["context"] or {}
                requests = [
                    batcher.row_context(entry) | {
                        "game_id": getattr(context.get(entry.job), "game_id", None),
                        "state_only": record["state_only"], "batch": record["batch"]}
                    for record in batches for entry in batcher.rows_of(record)
                ]
                if building is not None:
                    requests.extend({"game_id": getattr(context.get(job), "game_id", None),
                                     "job_id": job.job_id, "model_version": job.policy.model_version,
                                     "state_only": building["state_only"], "batch": building["batch"]}
                                    for job in building["chunk"])
                game_ids = sorted({item["game_id"] for item in requests if item["game_id"] is not None})
                scenes = [{"game_id": game_id,
                           "game_seed": active[game_id].stepper.trace["game_seed"],
                           "first_player": active[game_id].stepper.trace["first_player"],
                           "trace": active[game_id].stepper.trace,
                           "root_decision_index": active[game_id].stepper.decision_count,
                           "root_request": to_primitive(active[game_id].stepper.request)
                           if active[game_id].stepper.terminal is None else None}
                          for game_id in game_ids]
                batch_id = batches[0]["batch"] if batches else building["batch"]
                _atomic_json(root / "failures" / f"batch-{batch_id:06d}.json", {
                    "protocol": "search-accel-failure-v1", "scope": "batch",
                    "game_ids": game_ids, "games": scenes,
                    "batch_requests": requests,
                    "search_config": asdict(config.search_config),
                    "checkpoint_sha256": checkpoint_sha,
                    "error_type": type(error).__name__, "error_detail": str(error),
                    "traceback": error_text,
                })
            elif failed is not None:
                scene = {
                    "protocol": "search-accel-failure-v1", "scope": "row", "game_id": failed.game_id,
                    "game_seed": failed.stepper.trace["game_seed"],
                    "first_player": failed.stepper.trace["first_player"],
                    "trace": failed.stepper.trace,
                    "root_decision_index": failed.stepper.decision_count,
                    "root_request": to_primitive(failed.stepper.request) if failed.stepper.terminal is None else None,
                    "search_config": asdict(config.search_config),
                    "checkpoint_sha256": checkpoint_sha,
                    "batch_requests": [
                        {"request_id": item.request_id, "kind": item.kind,
                         "game_id": session.game_id,
                         "root_decision_index": session.stepper.decision_count,
                         "request": to_primitive(item.request),
                         "output": None if batch_outputs is None else to_primitive(batch_outputs[index])}
                        for index, (session, item) in enumerate(batch_context)
                    ],
                    "search_context": (None if failed.job is None else to_primitive(failed.job.failure_context(active_request_id))),
                    "error_type": type(error).__name__, "error_detail": str(error),
                    "traceback": error_text,
                }
                _atomic_json(root / "failures" / f"game-{failed.game_id:06d}.json", scene)
        except Exception:
            # Failure recording must never replace the search exception.
            pass
        raise
    window_ended = time.perf_counter()
    window_cpu_ended = _cpu_seconds()
    window_end_snapshot = _live_snapshot(evaluator, batcher, active.values(),
                                         finished_simulations, len(completed))
    if device == "cuda":
        torch.cuda.synchronize()
    tail_seconds = time.perf_counter() - window_ended
    return {
        "worker_id": game_ids[0],
        "completed": completed, "wall_seconds": time.perf_counter() - started,
        "initialization_seconds": initialization_seconds,
        "decision_latencies_ms": decision_latencies_ms,
        "inference": evaluator.stats.to_dict(),
        "counters": window_end_snapshot,
        "window": None if window_control is None else {
            "started_at": started, "ended_at": window_ended,
            "cpu_start": window_cpu_started, "cpu_end": window_cpu_ended,
            "cpu_seconds": window_cpu_ended - window_cpu_started,
            "start": window_start_snapshot, "end": window_end_snapshot,
            "tail_seconds": tail_seconds,
        },
        "peak_active_games": peak_active, "peak_pending_requests": peak_pending,
        "cpu_peak_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "gpu_peak_bytes": torch.cuda.max_memory_allocated() if device == "cuda" else 0,
    }


def _scan_committed(root: Path, config: FastSelfPlayConfig, manifest: Mapping[str, Any]) -> dict[int, dict[str, Any]]:
    complete: dict[int, dict[str, Any]] = {}
    for path in sorted((root / "games").glob("game-*.npz")):
        game_id = int(path.stem.removeprefix("game-"))
        if not 0 <= game_id < config.num_games or game_id in complete:
            raise ValueError(f"unexpected committed game {path}")
        with np.load(path, allow_pickle=False) as archive:
            metadata = json.loads(archive["metadata_json"].tobytes().decode("utf-8"))
        if (metadata.get("data_schema") != config.data_schema or
                (config.data_schema == DATA_SCHEMA_V3 and metadata.get("search_training") != config.search_training()) or
                metadata.get("semantic_fingerprint") != manifest["semantic_fingerprint"] or
                metadata.get("checkpoint_sha256") != manifest["checkpoint_identity"]["sha256"] or
                metadata.get("game_id") != game_id or
                metadata.get("game_seed") != derive_seed(config.seed, config.round_index, game_id, "game") or
                metadata.get("search_seeds") != list(_search_seeds(config, game_id))):
            raise ValueError(f"committed game identity mismatch: {path}")
        complete[game_id] = metadata
    return complete


def validate_run(root: Path, *, replay: bool = False) -> dict[str, Any]:
    root = Path(root)
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("protocol") != PROTOCOL:
        raise ValueError("v2 run manifest protocol mismatch")
    config = FastSelfPlayConfig.from_dict(manifest["config"])
    committed = _scan_committed(root, config, manifest)
    summary: dict[str, Any] = {
        "protocol": PROTOCOL, "expected_games": config.num_games,
        "completed_games": len(committed), "missing_games": config.num_games - len(committed),
        "p0_wins": 0, "p1_wins": 0, "draws": 0,
        "samples": 0, "policy_samples": 0, "simulations": 0,
        "data_bytes": 0, "search_seconds_sum": 0.0, "logical_model_positions": 0,
        "failed_games": 0, "exceptions": 0, "engineering_truncations": 0,
        "batch_failures": 0, "batch_failure_game_ids": [],
        "semantic_fingerprint": manifest["semantic_fingerprint"],
        "statistics_scope": "unavailable", "statistics_complete": False,
        "statistics_missing_game_ids": sorted(committed),
        "games_per_wall_second": None, "policy_samples_per_wall_second": None,
        "simulations_per_wall_second": None,
    }
    if config.data_schema == DATA_SCHEMA_V3:
        summary.update(low_budget_decisions=0, full_budget_decisions=0, forced_playouts=0, pruned_visits=0)
    for game_id, metadata in committed.items():
        path = game_path(root, game_id)
        arrays, metadata = load_game(path)
        counts = validate_game_arrays(arrays, metadata, expected_game_id=game_id,
                                      fingerprint=manifest["semantic_fingerprint"],
                                      simulations=config.search_config.simulations,
                                      worlds=config.search_config.determinizations,
                                      split=_split(config, game_id))
        if replay:
            replay_trace(metadata["trace"])
        summary["samples"] += counts["decisions"]
        summary["policy_samples"] += counts["policy_samples"]
        summary["simulations"] += counts["simulations"]
        if config.data_schema == DATA_SCHEMA_V3:
            for name in ("low_budget_decisions", "full_budget_decisions", "forced_playouts", "pruned_visits"):
                summary[name] += counts[name]
        summary["data_bytes"] += path.stat().st_size
        summary["search_seconds_sum"] += sum(s["total_seconds"] for s in metadata["mcts_stats"])
        summary["logical_model_positions"] += sum(s["model_positions"] for s in metadata["mcts_stats"])
        winners = metadata["terminal_result"]["winner_ids"]
        summary["draws" if len(winners) == 2 else ("p0_wins" if winners[0] == 0 else "p1_wins")] += 1
    failure_root = root / "failures"
    batch_game_ids: set[int] = set()
    failures_by_game: dict[int, str] = {}
    outstanding_rows: dict[tuple[int, int, int], dict[int, int]] = {}
    for scene_path in failure_root.glob("batch-*.json"):
        scene = json.loads(scene_path.read_text(encoding="utf-8"))
        summary["batch_failures"] += 1
        batch_game_ids.update(scene.get("game_ids", []))
    for scene_path in failure_root.glob("game-*.json"):
        game_id = int(scene_path.stem.removeprefix("game-"))
        scene = json.loads(scene_path.read_text(encoding="utf-8"))
        failures_by_game[game_id] = scene.get("error_detail", "")
    for scene_path in failure_root.glob("worker-*.json"):
        scene = json.loads(scene_path.read_text(encoding="utf-8"))
        detail = scene.get("error_detail", "")
        failed_game_id = scene.get("failed_game_id")
        for game in scene.get("games", []):
            game_id = game["game_id"]
            failures_by_game[game_id] = (detail if failed_game_id is None or
                                         game_id == failed_game_id else "interrupted by worker failure")
        for slot in scene.get("outstanding", []):
            rows = {row["row"]: row["game_id"] for row in slot.get("rows", [])}
            outstanding_rows[scene["worker_id"], slot["slot"], slot["generation"]] = rows
            for game_id in rows.values():
                failures_by_game.setdefault(game_id, detail)
    owner_path = failure_root / "owner.json"
    if owner_path.exists():
        owner_scene = json.loads(owner_path.read_text(encoding="utf-8"))
        if owner_scene.get("origin") == "inference" or (
                "origin" not in owner_scene and owner_scene.get("requests") and
                not owner_scene.get("error_detail", "").startswith("search worker ")):
            summary["batch_failures"] += 1
            for request in owner_scene.get("requests", []):
                rows = outstanding_rows.get((request["worker_id"], request["slot"],
                                             request["generation"]), {})
                batch_game_ids.update(rows[row] for row in range(
                    request["row_offset"], request["row_offset"] + request["rows"])
                    if row in rows)
    for game_id, detail in failures_by_game.items():
        if game_id in committed:
            continue
        summary["failed_games"] += 1
        if detail == "engineering turn limit reached without formal terminal":
            summary["engineering_truncations"] += 1
        else:
            summary["exceptions"] += 1
    summary["batch_failure_game_ids"] = sorted(batch_game_ids)
    status_path = root / "status.json"
    if status_path.exists():
        status = json.loads(status_path.read_text(encoding="utf-8"))
        summary.update({key: status[key] for key in ("wall_seconds", "inference", "cpu_peak_rss_kib",
                                                    "gpu_peak_bytes", "peak_active_games", "peak_pending_requests",
                                                    "decision_latency", "root_encoding_seconds",
                                                    "real_rule_seconds", "search_rule_seconds", "native_encoding_seconds",
                                                    "native_compute_seconds", "write_seconds",
                                                    "queue_wait_seconds", "worker_initialization_seconds_sum",
                                                    "worker_collection_wall_seconds_max",
                                                    "native_batch_rows", "native_batch_batches", "native_root_rows",
                                                    "native_policy_rows", "native_value_rows", "native_wide_batches",
                                                    "peak_inflight_rows", "native_fill_seconds", "native_consume_seconds",
                                                    "pipeline_slots", "compile_failure_policy",
                                                    "worker_compile", "statistics_scope", "statistics_game_ids")
                        if key in status})
        # Wall time and shared physical batches cannot be recovered by summing
        # archived game durations: games/workers overlap. Only use the games
        # covered by this collection session as throughput numerators.
        measured_ids = status.get("statistics_game_ids")
        if status.get("statistics_scope") == "collection_session" and isinstance(measured_ids, list):
            measured = set(measured_ids)
            if len(measured) != len(measured_ids) or not measured.issubset(committed):
                raise ValueError("collection statistics refer to invalid game ids")
            summary["statistics_complete"] = measured == set(committed)
            summary["statistics_missing_game_ids"] = sorted(set(committed) - measured)
            wall = summary.get("wall_seconds", 0.0)
            summary["games_per_wall_second"] = len(measured) / wall if wall else 0.0
            policy_samples = sum(committed[i]["policy_samples"] for i in measured)
            simulations = sum(s["simulations"] for i in measured for s in committed[i]["mcts_stats"])
            summary["policy_samples_per_wall_second"] = policy_samples / wall if wall else 0.0
            summary["simulations_per_wall_second"] = simulations / wall if wall else 0.0
        else:
            # Legacy status files do not identify their coverage; resume may
            # already have lost historical costs. Do not invent whole-run rates.
            summary["statistics_scope"] = "unknown"
            summary["statistics_complete"] = False
            for metric in ("games", "policy_samples", "simulations"):
                summary[f"{metric}_per_wall_second"] = None
    return summary


def generate(
    config: FastSelfPlayConfig,
    root: Path,
    *,
    resume: bool = False,
    progress_callback: Callable[[int, int], None] | None = None,
    progress_interval_seconds: float = PROGRESS_POLL_SECONDS,
) -> dict[str, Any]:
    """Collect the missing games of one run.

    ``progress_callback`` runs in the parent process with
    ``(completed_games, total_games)``: single-worker runs report every commit,
    multi-worker runs poll the archive directory every
    ``progress_interval_seconds`` so partial progress stays visible while the
    pool is still working.
    """

    if progress_interval_seconds <= 0:
        raise ValueError("progress_interval_seconds must be positive")
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(root, os.O_RDONLY)
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        manifest_path = root / "manifest.json"
        if manifest_path.exists():
            if not resume:
                raise ValueError("output run exists; use --resume")
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            current = build_manifest(config)
            if manifest.get("semantic_fingerprint") != current["semantic_fingerprint"]:
                raise ValueError("resume semantic fingerprint mismatch")
        else:
            if any(root.iterdir()):
                raise ValueError("nonempty output directory has no v2 manifest")
            if resume:
                raise ValueError("cannot resume an empty run")
            manifest = build_manifest(config)
            _atomic_json(manifest_path, manifest)
        complete = _scan_committed(root, config, manifest)
        missing = tuple(game_id for game_id in range(config.num_games) if game_id not in complete)
        if not missing:
            return validate_run(root)
        if config.execution.backend in ("batched_cuda", "native_cuda", "native_cuda_pool") and not torch.cuda.is_available():
            raise RuntimeError(f"{config.execution.backend} requested but CUDA is unavailable")
        started = time.perf_counter()
        owner_stats = None
        groups = tuple(tuple(missing[i::config.execution.workers]) for i in range(config.execution.workers))
        groups = tuple(group for group in groups if group)
        checkpoint_sha = manifest["checkpoint_identity"]["sha256"]
        if config.execution.backend == "native_cuda_pool":
            from .multiworker_gpu import collect as collect_gpu_pool
            results, owner_stats = collect_gpu_pool(
                config, root, missing, manifest["semantic_fingerprint"], checkpoint_sha,
                progress_callback, len(complete))
            results[0]["inference"] = owner_stats["inference"]
        elif len(groups) == 1:
            results = [_collect_group(
                config, root, groups[0], manifest["semantic_fingerprint"], checkpoint_sha,
                completed_before=len(complete), on_game_complete=progress_callback,
            )]
        else:
            with mp.Manager() as manager:
                stop_event = manager.Event()
                with ProcessPoolExecutor(max_workers=len(groups), mp_context=mp.get_context("spawn")) as pool:
                    futures = [pool.submit(_collect_group, config, root, group,
                                           manifest["semantic_fingerprint"], checkpoint_sha,
                                           stop_event) for group in groups]
                    try:
                        if progress_callback is None:
                            results = [future.result() for future in as_completed(futures)]
                        else:
                            results = []
                            pending = set(futures)
                            while pending:
                                finished, pending = wait(
                                    pending,
                                    timeout=progress_interval_seconds,
                                    return_when=FIRST_COMPLETED,
                                )
                                for future in finished:
                                    results.append(future.result())
                                progress_callback(_committed_game_count(root), config.num_games)
                    except Exception:
                        stop_event.set()
                        for future in futures:
                            future.cancel()
                        raise
        # Each successful invocation reports its own cost and explicit coverage.
        # Never merge an old session with possibly unmeasured committed games.
        status_path = root / "status.json"
        physical = {
            "physical_model_batches": sum(item["inference"]["physical_model_batches"] for item in results),
            "logical_model_positions": sum(item["inference"]["logical_model_positions"] for item in results),
            "feature_seconds": sum(item["inference"]["feature_seconds"] for item in results),
            "forward_seconds": sum(item["inference"]["forward_seconds"] for item in results),
            "h2d_seconds": sum(item["inference"]["h2d_seconds"] for item in results),
            "d2h_seconds": sum(item["inference"]["d2h_seconds"] for item in results),
            "wait_seconds": sum(item["inference"]["wait_seconds"] for item in results),
            "batch_size_histogram": {},
        }
        hist = physical["batch_size_histogram"]
        for item in results:
            for size, count in item["inference"]["batch_size_histogram"].items():
                hist[size] = hist.get(size, 0) + count
        batches = physical["physical_model_batches"]
        physical["mean_batch_size"] = physical["logical_model_positions"] / batches if batches else 0.0
        import statistics
        latencies = [value for result in results for value in result["decision_latencies_ms"]]
        ordered_latencies = sorted(latencies)
        status = {
            "statistics_scope": "collection_session",
            "statistics_game_ids": sorted(game["game_id"] for result in results for game in result["completed"]),
            "wall_seconds": time.perf_counter() - started,
            "decision_latencies_ms": latencies,
            "decision_latency": {
                "count": len(latencies),
                "p50_ms": statistics.median(latencies) if latencies else 0.0,
                "p95_ms": ordered_latencies[min(len(latencies) - 1, int(len(latencies) * 0.95))] if latencies else 0.0,
                "max_ms": max(latencies) if latencies else 0.0,
            },
            "root_encoding_seconds": sum(
                game["root_encoding_seconds"] for result in results for game in result["completed"]),
            "real_rule_seconds": sum(
                game["real_rule_seconds"] for result in results for game in result["completed"]),
            "search_rule_seconds": sum(
                game["search_rule_seconds"] for result in results for game in result["completed"]),
            "native_encoding_seconds": sum(
                game["native_encoding_seconds"] for result in results for game in result["completed"]),
            "native_compute_seconds": sum(
                game["native_compute_seconds"] for result in results for game in result["completed"]),
            "write_seconds": sum(
                game["write_seconds"] for result in results for game in result["completed"]),
            "queue_wait_seconds": 0.0,
            "worker_initialization_seconds_sum": sum(
                result["initialization_seconds"] for result in results),
            "worker_collection_wall_seconds_max": max(result["wall_seconds"] for result in results),
            "inference": physical,
            "worker_compile": [
                {"worker_id": item["worker_id"],
                 "inference": item["inference"]["inference"],
                 "compile": item["inference"]["compile"]}
                for item in sorted(results, key=lambda result: result["worker_id"])
            ],
            "native_batch_rows": sum(item["counters"].get("native_batch_rows", 0) for item in results),
            "native_batch_batches": sum(item["counters"].get("native_batch_batches", 0) for item in results),
            "native_root_rows": sum(item["counters"].get("native_root_rows", 0) for item in results),
            "native_policy_rows": sum(item["counters"].get("native_policy_rows", 0) for item in results),
            "native_value_rows": sum(item["counters"].get("native_value_rows", 0) for item in results),
            "native_wide_batches": sum(item["counters"].get("native_wide_batches", 0) for item in results),
            "peak_inflight_rows": max(item["counters"].get("native_peak_inflight_rows", 0) for item in results),
            "native_fill_seconds": sum(item["counters"].get("native_fill_seconds", 0.0) for item in results),
            "native_consume_seconds": sum(item["counters"].get("native_consume_seconds", 0.0) for item in results),
            "pipeline_slots": config.execution.pipeline_slots,
            "compile_failure_policy": config.execution.compile_failure_policy,
            "peak_active_games": max(r["peak_active_games"] for r in results),
            "peak_pending_requests": max(r["peak_pending_requests"] for r in results),
            "cpu_peak_rss_kib": max(r["cpu_peak_rss_kib"] for r in results),
            "gpu_peak_bytes": max(r["gpu_peak_bytes"] for r in results),
        }
        if owner_stats is not None:
            status["gpu_owner"] = owner_stats
            status["worker_compile"] = [{
                "worker_id": "gpu_owner", "inference": owner_stats["inference"]["inference"],
                "compile": owner_stats["inference"]["compile"],
            }]
            status["peak_active_games"] = sum(item["peak_active_games"] for item in results)
            status["gpu_peak_bytes"] = owner_stats["gpu_peak_bytes"]
            status["cpu_peak_rss_kib"] = max(
                status["cpu_peak_rss_kib"], owner_stats["owner_cpu_peak_rss_kib"])
            status["queue_wait_seconds"] = sum(item["wait_result_seconds"] for item in results)
            status["worker_cpu_seconds"] = [item["cpu_seconds"] for item in results]
            status["wait_result_seconds"] = sum(item["wait_result_seconds"] for item in results)
            status["queue_backpressure_seconds"] = sum(
                item["queue_backpressure_seconds"] for item in results)
        _atomic_json(status_path, status)
        summary = validate_run(root)
        _atomic_json(root / "summary.json", summary)
        return summary
    finally:
        fcntl.flock(descriptor, fcntl.LOCK_UN)
        os.close(descriptor)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    command = commands.add_parser("generate")
    command.add_argument("--config", type=Path, required=True)
    command.add_argument("--output", type=Path, required=True)
    command.add_argument("--resume", action="store_true")
    for name in ("validate", "inspect"):
        command = commands.add_parser(name)
        command.add_argument("--input", type=Path, required=True)
        command.add_argument("--replay", action="store_true")
    args = parser.parse_args(argv)
    if args.command == "generate":
        config = FastSelfPlayConfig.from_dict(json.loads(args.config.read_text(encoding="utf-8")))
        summary = generate(config, args.output, resume=args.resume)
    else:
        summary = validate_run(args.input, replay=args.replay)
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
