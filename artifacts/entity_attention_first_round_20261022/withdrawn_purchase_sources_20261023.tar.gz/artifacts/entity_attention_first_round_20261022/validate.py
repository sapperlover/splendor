"""Four archived games, checked label replay, 12 updates and three S8 roots only."""
from __future__ import annotations

import argparse
from dataclasses import asdict, replace
import json
import random
from pathlib import Path
import sys
import time

import numpy as np
import torch

from splendor.actor_critic import tensorize_batch
from splendor.alphazero_checkpoint import load_alphazero_checkpoint
from splendor.alphazero_recording import environment_identity, read_json, sha256, source_identity, write_json
from splendor.benchmark_search import fixed_requests
from splendor.catalog import load_catalog, load_default_catalog
from splendor.contracts import DecisionRequest
from splendor.engine import GameEngine
from splendor.features import collate_encoded_decisions, encode_decision, encode_decision_state
from splendor.mcts_policy import MCTSConfig
from splendor.model import DecisionPhase
from splendor.native_policy import NativeBatchRunner, NativePUCTSearchPolicy
from splendor.offline_first_round import FirstRoundOfflineConfig, run, select_checkpoint
from splendor.opponent_pool import load_frozen_actor_critic_checkpoint
from splendor.progress_auxiliary import HORIZONS, game_progress_targets
from splendor.purchase_outcomes import PURCHASE_SUMMARY_NAMES, purchase_outcome_features
from splendor.replay import _decode_action, to_primitive
from splendor.search_inference import FrozenSearchInference, InferenceConfig
from splendor.selfplay_data import load_game

ART = Path(__file__).resolve().parent
ROOT = ART.parents[1]
CONFIG = ROOT / 'configs/entity_attention_v1/offline_first_round_r21_r31_20261022.json'


def check_labels(arrays, metadata):
    trace = metadata['trace']
    if trace['catalog_fingerprint'] != load_default_catalog().data_fingerprint:
        raise ValueError('validator requires the current catalog')
    engine = GameEngine.new(trace['game_seed'], first_player=trace['first_player'], mode='checked')
    snapshots, purchase_checks, roots = [], [], []
    for i, item in enumerate(trace['actions']):
        request = engine.decision()
        assert isinstance(request, DecisionRequest)
        action = _decode_action(item['action'])
        assert action == request.legal_actions[item['candidate_index']]
        observation = engine.observation_for(0)
        snapshots.append(observation)
        if request.observation.phase is DecisionPhase.MAIN_ACTION:
            roots.append(i)
            if type(action).__name__ in ('BuyMarket', 'BuyReserved'):
                batch = tensorize_batch(collate_encoded_decisions([encode_decision(request)]))
                summary = purchase_outcome_features(batch)[2][0, item['candidate_index']]
                purchase_checks.append((i, item['player_id'], dict(zip(PURCHASE_SUMMARY_NAMES, summary.tolist()))))
        engine.apply(action)
    final = engine.observation_for(0)
    assert to_primitive(engine.decision()) == metadata['terminal_result']
    labels = game_progress_targets(arrays, metadata)
    checked = 0
    for i in roots:
        start = snapshots[i]
        t = start.own_completed_turns + start.opponent_completed_turns
        p = int(arrays['player_id'][i])
        for hindex, horizon in enumerate(HORIZONS):
            future = next((o for o in snapshots[i+1:] if o.phase is DecisionPhase.MAIN_ACTION
                           and o.own_completed_turns + o.opponent_completed_turns >= t+horizon), final)
            before = (start.self_public, start.opponent_public)
            after = (future.self_public, future.opponent_public)
            for relative in (0, 1):
                actor = (p + relative) % 2
                assert labels['progress_score'][i, hindex, relative] == after[actor].score - before[actor].score
                expected = np.asarray(tuple(after[actor].bonuses)) - np.asarray(tuple(before[actor].bonuses))
                np.testing.assert_array_equal(labels['progress_bonus'][i, hindex, relative], expected)
            checked += 1
    for i, p, summary in purchase_checks:
        future = next((o for o in snapshots[i+1:] if o.phase is DecisionPhase.MAIN_ACTION), final)
        player = (future.self_public, future.opponent_public)[p]
        assert abs(summary['score_after']*15 - player.score) < 1e-5
        terminal = future.result is not None
        assert bool(summary['ends_now']) == terminal
        assert bool(summary['opponent_reply']) == (future.final_round_triggered and not terminal)
    return {'main_horizon_labels': checked, 'purchase_settlements': len(purchase_checks),
            'terminal_phase_before_last_action': trace['actions'][-1]['phase']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device', choices=('cpu', 'cuda'), required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    tick = time.perf_counter()
    config = FirstRoundOfflineConfig.from_dict(read_json(CONFIG))
    runtime = ROOT / 'runtime' / ART.name
    if config.progress_auxiliary is None:
        runtime = runtime / 'purchase_only_20261023'
    runtime = runtime / args.device
    runtime.mkdir(parents=True, exist_ok=True)
    records, counts = [], {'train': 0, 'validation': 0}
    for line in Path(config.manifest).read_text().splitlines():
        row = json.loads(line)
        if row['round_index'] != config.first_round - 1 or counts[row['split']] >= 2:
            continue
        records.append(row)
        counts[row['split']] += 1
        if len(records) == 4:
            break
    assert counts == {'train': 2, 'validation': 2}
    labels = []
    for row in records:
        arrays, metadata = load_game(Path(row['path']))
        labels.append({'path': row['path'], 'sha256': sha256(Path(row['path'])), **check_labels(arrays, metadata)})
    manifest = runtime / 'manifest.jsonl'
    manifest.write_text(''.join(json.dumps(r)+'\n' for r in records))
    positions = sum(r['decision_count'] for r in records if r['split'] == 'train')
    config = replace(config, manifest=str(manifest), manifest_sha256=sha256(manifest),
        last_round=config.first_round, expected_games_per_round=4, cache_mib=64,
        draw_exposures=11.5*16/positions, validation_positions=32, validation_percent_step=50,
        learner=replace(config.learner, device=args.device, batch_size=16, history_batch_size=8,
                        checkpoint_every_steps=4, validation_batch_size=32))
    write_json(runtime / 'smoke_config.json', asdict(config))
    run(config, runtime / 'fit')
    selected = select_checkpoint(config, runtime / 'fit')
    checkpoint = runtime / 'fit/checkpoints/final.pt'
    model = load_frozen_actor_critic_checkpoint(checkpoint).to(args.device).eval()
    assert load_alphazero_checkpoint(checkpoint).round_train_step == 12
    requests = [request for _, request, _ in fixed_requests()]
    encoded = [encode_decision(request) for request in requests]
    states = [encode_decision_state(request) for request in requests]
    eager = FrozenSearchInference(model, device=args.device, config=InferenceConfig(actor_projection=False))
    evaluator = FrozenSearchInference(model, device=args.device, config=InferenceConfig(
        mode='compiled', actor_projection=False, candidate_buckets=(16, 32, 48, 64),
        native_transport='reused', compile_failure_policy='fail_fast'))
    expected = eager.policy_value_encoded(encoded)
    for left, right in zip(expected, evaluator.policy_value_encoded(encoded)):
        torch.testing.assert_close(torch.tensor(left[0]), torch.tensor(right[0]), atol=2e-5, rtol=2e-4)
        torch.testing.assert_close(torch.tensor(left[1]), torch.tensor(right[1]), atol=2e-5, rtol=2e-4)
    torch.testing.assert_close(torch.tensor([v for _, v in expected]),
                               torch.tensor(evaluator.value_only_encoded(states)), atol=2e-5, rtol=2e-4)
    policies = [NativePUCTSearchPolicy(model, device=args.device, evaluator=evaluator,
        config=MCTSConfig(simulations=8, determinizations=1, root_noise_fraction=0., seed=44530000+i))
        for i in range(len(requests))]
    jobs = [policy.start_job(request) for policy, request in zip(policies, requests)]
    runner = NativeBatchRunner(evaluator, load_default_catalog(), capacity=4, buckets=(16, 32, 48, 64))
    while not all(job.done for job in jobs):
        assert runner.run([job for job in jobs if not job.done]) > 0
    assert all(job.result.simulations == 8 for job in jobs)
    stats = evaluator.compiled.stats.to_dict()
    assert stats['compile_failure_fallbacks'] == 0
    legacy_art = ROOT / 'artifacts/entity_attention_relations_20261019'
    legacy_path = ROOT / read_json(legacy_art / 'legacy_reference_identity.json')['checkpoint']
    legacy = load_frozen_actor_critic_checkpoint(legacy_path).eval()
    # The legacy golden predates the 12-noble catalog. Recreate its exact
    # ten-noble input trajectory instead of comparing different observations.
    legacy_catalog = load_catalog(ROOT / 'artifacts/entity_attention_r20_search_stability_128_20261021/historical_catalog')
    legacy_engine = GameEngine.new(42, first_player=0, catalog=legacy_catalog, mode='checked')
    legacy_rng, legacy_encoded = random.Random(42 ^ 0xBEEF), []
    for index in range(41):
        request = legacy_engine.decision()
        assert isinstance(request, DecisionRequest)
        if index in (0, 20, 40):
            legacy_encoded.append(encode_decision(request))
        legacy_engine.apply(request.legal_actions[legacy_rng.randrange(len(request.legal_actions))])
    with np.load(legacy_art / 'legacy_reference.npz') as golden, torch.inference_mode():
        for name, value in zip(('logits', 'value'), legacy(collate_encoded_decisions(legacy_encoded))):
            torch.testing.assert_close(value, torch.from_numpy(golden[name]), atol=0, rtol=0)
    result = {'status': 'passed', 'scope': __doc__, 'device': args.device, 'seed': config.initialization_seed,
        'command': [sys.executable, *sys.argv], 'parameters': sum(p.numel() for p in model.parameters()),
        'model_config': asdict(model.config), 'progress_auxiliary': config.progress_auxiliary,
        'labels': labels, 'updates': 12, 'native_roots': len(jobs),
        'simulations_per_root': 8, 'total_search_simulations': len(jobs)*8, 'compile': stats,
        'eager_compiled_state_only_match': True, 'legacy_r43_bitwise_unchanged': True,
        'legacy_golden_catalog_fingerprint': legacy_catalog.data_fingerprint,
        'selection': selected, 'checkpoint_sha256': sha256(checkpoint), 'config_sha256': sha256(CONFIG),
        'environment': environment_identity(), 'source': source_identity(ROOT, runtime / 'source'),
        'seconds': time.perf_counter()-tick}
    suffix = '_purchase_only_20261023' if config.progress_auxiliary is None else ''
    write_json(ART / f'{args.device}{suffix}_validation.json', result)
    print({k: result[k] for k in ('status', 'device', 'parameters', 'updates', 'native_roots', 'seconds')}, flush=True)


if __name__ == '__main__':
    main()
