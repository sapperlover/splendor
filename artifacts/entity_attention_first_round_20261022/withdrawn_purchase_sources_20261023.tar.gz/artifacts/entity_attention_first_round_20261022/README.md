# Attention 首轮：购买结算关系（短期进展辅助已关闭）

**2026-10-23当前配方：按用户要求关闭短期进展辅助，仅保留购买结算特征。** `progress_auxiliary=null`且入口默认关闭，不构建辅助头、不生成未来标签、不追加辅助loss；当前架构`entity_attention_v1`、587138参数。旧显式启用配置及checkpoint保留支持。原准备目录`runs/entity_attention_first_round_r21_r31_20261022/`与原CPU／CUDA短验证保留，当前脚本改用独立的`runs/entity_attention_purchase_only_r21_r31_20261023/`；本次不启动正式训练。当前准备与验证见[purchase_only_20261023.json](purchase_only_20261023.json)，购买特征的只读冗余审查见[purchase_redundancy_20261023.md](purchase_redundancy_20261023.md)，特征结构未改。

2026-10-22的历史交付为购买结算关系＋短期进展辅助，正式训练仅prepare。下述辅助设计、134项测试及原CPU／CUDA短验证描述当时的组合候选，不代表当前配方仍启用辅助头。

## 模型和输入

沿用128×2／4头／FFN512、`market_relations=true`、`value_readout=global_players_market`。新增模型开关`purchase_outcomes`，默认false；旧checkpoint省略时保持原计算和参数。开启后仅对MAIN_ACTION的BuyMarket／BuyReserved候选，从原148／82／17维数值输入计算：

- 每位贵族18维关系：需求5、购买后己方缺口5、对手缺口5、缺口减少量、购买后满足、此次新满足。通过共享18→128＋GELU，再按有效贵族取均值。
- 每个购买候选8维结算摘要：卡牌分／5、本回合贵族分／3、结算后己方总分／15、达到15分、首次触发最后一轮、己方完成后双方回合已相等、对手尚欠补齐回合、购买后双方已购卡数量差／90。8→128无偏置投影，与贵族关系一起加入原动作query。

当前所有贵族均3分，多位满足也只计一位；已满足但尚未取得的贵族同样可在该回合领取。“双方回合相等／对手欠回合”依据本回合完成时的回合计数，先于可能发生的自动forced skip；欠回合不保证对手实际获得一次可选决策。达到15分不等于获胜，特征不含必胜判断。已购卡数差是同分裁决相关信息，不是胜负标签。

非购买动作、PAYMENT／RETURN_TOKENS／CHOOSE_NOBLE阶段、未知目标和padding的新增分支均为零。贵族集合和候选保持置换不变／等变；没有槽位或ID embedding。没有预设支付、归还或未来补牌。第一版没有实现拿币后购卡机会、资源竞争、对手暗保留威胁或反事实动作价值。

新增特征只作用于actor query；value-only不执行该分支。原始特征schema、Python／native传输及历史NPZ不变。

| 模型 | 参数 |
| --- | ---: |
| 原关系attention128 | 583682 |
| 加购买结算关系 | 587138 |
| 加短期进展辅助头的完整候选 | 670338 |

特征增加3456参数；训练用辅助头增加83200参数。正常policy/value推理与native搜索不执行辅助头，checkpoint仍保存它。未测生产B500吞吐，参数增量不等于延迟增量。

## 历史可选辅助标签与损失（当前关闭）

新架构`entity_attention_progress_v1`，标签协议`short-progress-main-h2-h4-v1`。一个128维输出头读取与value相同的全局／双方／市场表示，预测未来2、4个**完整玩家回合**后的双方进展：

- 得分增量：每个玩家、每个跨度17分类，0–16分。
- 五色加成增量：每个玩家、跨度、颜色各3分类，0／1／2张。

通常2个玩家回合就是双方各行动一次。支付、归还、选贵族不增加回合；标签只在MAIN_ACTION样本上生效。终局提前到来时使用真实终态并保持吸收；终局分数取`terminal_result`，最后一步若为Pay，补入pending卡带来的永久加成。若最后为选贵族，之前购买已计入观察，不再次增加。forced skip仅推进回合，资源不变。所有输出固定到样本当前行动者／对手视角。

标签由同一对局后续状态生成，没有重跑搜索；描述历史策略的实际后续，不是未选动作的反事实收益。每个归档在compact LRU加载时生成一次，新增数组计入同一内存上限、随游戏一起淘汰；不改写NPZ，不把未来信息传入模型。v1协议按双人现行规则固定跨度及类别，标签越界明确报错，不clip。

保留原两头独立抽样：policy仅抽正权重高预算步B256，value从全部预算步抽B256。辅助头复用value前向的状态编码，对value batch中的主行动监督；不改变引用账本和抽样RNG。

```text
L_progress = (mean CE_score + mean CE_bonus) / 2
L_total = L_policy_high + L_winloss_all + 0.05 * L_progress
```

score CE先平均两个跨度和双方；bonus CE再平均五色；各自按有效主行动的value_weight归一化。无有效主行动的batch贡献零，日志同时记录`progress_positions`，不能将这类零loss解读为预测准确。梯度进入共享encoder；主胜负头仍拟合终局z，原旧分差／剩余回合辅助均关闭。

## 配置、命令和成本控制

配置：[offline_first_round_r21_r31_20261022.json](../../configs/entity_attention_v1/offline_first_round_r21_r31_20261022.json)，当前`progress_auxiliary=null`；旧组合候选冻结配置保存在原run的`config.json`及原准备记录。入口：[offline_first_round.py](../../src/splendor/offline_first_round.py)。

复用现有12贵族的第21–31轮44000局原split：39629训练局／3170796位置，4371留出局／349435位置；有效policy标签664043／72631。原始数据、固定4096留出、种子、两头采样和更新日程均对齐原离线基线。随机初始化、全新AdamW，lr1e-4，wd1e-4，clip1，FP32、16GiB缓存。

上限沿用12次value抽样曝光、148632步；这不是本次已运行的预算，也不是要求跑满。每5%完整留出KL＋胜负MSE连续三次严格上升即早停，持平／下降重置；辅助loss不进入早停和选点，按实际到达节点选择整个checkpoint，结束不自动对战。源config／数据身份变化不能在原目录续训。训练会话保存命令、源码快照、代码身份、RNG和抽样账本。

从仓库根目录执行：

```bash
# 只准备和核验输入（本次已执行，不初始化模型、不训练）
bash scripts/run_attention_first_round_20261022.sh --prepare-only

# 正式启动／中断后从已提交节点继续（本次未执行）
bash scripts/run_attention_first_round_20261022.sh

# 限制本次调用最多新增1000步；仍使用正式候选目录和冻结总日程
bash scripts/run_attention_first_round_20261022.sh --max-steps-this-session 1000

# 已完成后重新读取完整留出选点
bash scripts/run_attention_first_round_20261022.sh --select-only
```

限步调用不会额外插入百分比之外的留出评估，也不提前选点；应结合逐步主任务loss排查工程异常。当前正式候选在`runs/entity_attention_purchase_only_r21_r31_20261023/`，最佳整个checkpoint路径写在`selection.json`。当前该目录只有准备产物，没有checkpoint；当前对齐核验见[purchase_only_20261023.json](purchase_only_20261023.json)；旧组合准备见[preparation.json](preparation.json)。

## 工程验证

- [CPU回归](tests.xml)：134项通过，覆盖特征手算／mask／置换／末轮时序、终局Pay与贵族标签、forced skip时钟、辅助梯度、原两头抽样、LRU容量、严格checkpoint加载、中断续训模型与AdamW逐位一致、准备／选点记录与真实模型初始化身份一致、旧scratch／mixed／早停／降lr入口。
- [CPU](cpu_validation.json)和[RTX4050 CUDA](cuda_validation.json)：各复用4个真实历史归档、12次B16更新；424个“主行动×跨度”标签与78个购买回合结算对checked引擎核对；eager／compiled／state-only一致，3个原生S8N1搜索根，每组总24模拟，编译fallback为0。
- 原R43输入／输出逐位保持不变。首次验证误用了当前12贵族输入与历史10贵族golden比较；修正验证器为重建原10贵族输入后通过，未更改旧golden或模型代码。第一次汇总误将冻结模型的可训练参数数记为0，已从同一checkpoint重算全部参数并保留`parameter_count_correction`说明；不是训练／推理失败。

以上是工程验证，不是正式训练或棋力结论；短训loss不能证明新方案有效。未做正式greedy／搜索对战、长时间学习收敛或全规模吞吐测量。已有基线可用于首次筛选，整套候选有效也不能独立归因于某个特征或辅助头。

最终核对另修正了复用入口的计划描述：首轮`plan.json`现在记录真实的progress架构和辅助初始化种子，选点时也保持该身份。修正只影响计划元数据，不改模型、标签、抽样或更新；完整回归重新通过，CPU／CUDA短训的原始来源身份保留，当前源码与验证范围见[verification.json](verification.json)。

有限验证脚本（只在独立runtime目录训练12步，已完成时复用其已提交结果，不触碰正式候选）：

```bash
conda run --no-capture-output -n splendor env PYTHONPATH=src OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  TORCHINDUCTOR_COMPILE_THREADS=1 python artifacts/entity_attention_first_round_20261022/validate.py --device cpu
conda run --no-capture-output -n splendor env PYTHONPATH=src OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  TORCHINDUCTOR_COMPILE_THREADS=1 python artifacts/entity_attention_first_round_20261022/validate.py --device cuda
```

当前无辅助验证写入`runtime/entity_attention_first_round_20261022/purchase_only_20261023/<device>/`，报告文件带`purchase_only_20261023`后缀；原CPU／CUDA组合短验证路径和原件保留。验证checkpoint、训练曲线和源码位于忽略的`runtime/entity_attention_first_round_20261022/`；本目录保存小型结果、核验命令与来源身份。未提交、推送或调整忽略规则。
