from dataclasses import asdict, replace
import json
from pathlib import Path

import numpy as np
import pytest
import torch

from test_alphazero_training import az_runs
from splendor.actor_critic import TorchStateBatch, build_actor_critic, tensorize_batch
from splendor.alphazero_checkpoint import load_alphazero_checkpoint
from splendor.alphazero_recording import read_json, sha256
from splendor.alphazero_replay import build_replay_index
from splendor.alphazero_train import LearnerConfig
from splendor.engine import GameEngine
from splendor.features import ACTION_FEATURE_NAMES as A, GLOBAL_FEATURE_NAMES as G
from splendor.features import collate_encoded_decisions, encode_decision
from splendor.offline_first_round import FirstRoundOfflineConfig, initialize_learner, prepare_inputs, run, select_checkpoint
from splendor.offline_mixed_budget import make_batch_drawer, prepare_inputs as prepare_mixed_inputs
from splendor.offline_early_stopping import EarlyStoppingOfflineConfig
from splendor.opponent_pool import load_frozen_actor_critic_checkpoint
from splendor.progress_auxiliary import (HORIZONS, ProgressAuxiliaryConfig, add_progress_head,
    game_progress_targets, progress_loss_sums, progress_targets)
from splendor.purchase_outcomes import PURCHASE_SUMMARY_NAMES, purchase_outcome_features
from splendor.rng import DeterministicRng


@pytest.fixture(autouse=True, scope="module")
def one_thread():
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(previous)


def purchase_batch():
    batch = tensorize_batch(collate_encoded_decisions([encode_decision(GameEngine.new(42).decision())]))
    g = batch.global_features.clone()
    g[:, G.index("self_bonus_white_scaled"):G.index("self_bonus_white_scaled") + 5] = torch.tensor([3, 4, 4, 0, 0]) / 18
    g[:, G.index("self_score_scaled")] = 11 / 15
    g[:, G.index("self_purchased_cards_scaled")] = 11 / 90
    g[:, G.index("opponent_purchased_cards_scaled")] = 10 / 90
    g[:, G.index("own_completed_turns_scaled")] = 20 / 40
    g[:, G.index("opponent_completed_turns_scaled")] = 20 / 40
    nobles = torch.zeros_like(batch.nobles)
    nobles[0, :2, 0:2] = 1
    nobles[0, 0, 2:7] = torch.tensor([4, 4, 0, 0, 0]) / 4
    nobles[0, 1, 2:7] = torch.tensor([4, 0, 4, 0, 0]) / 4
    nobles[0, :2, 7] = .25
    nobles[0, 2] = float("nan")
    actions = torch.zeros(1, 3, 82)
    actions[0, 0, A.index("phase_main_action")] = 1
    actions[0, 0, A.index("type_buy_market")] = 1
    actions[0, 0, A.index("target_card.valid")] = 1
    actions[0, 0, A.index("target_card.known")] = 1
    actions[0, 0, A.index("target_card.bonus_white")] = 1
    actions[0, 0, A.index("target_card.points_scaled")] = 1 / 5
    actions[0, 1, A.index("type_reserve_market")] = 1
    actions[0, 2] = float("nan")
    return replace(batch, global_features=g, nobles=nobles,
                   nobles_mask=torch.tensor([[True, True, False]]), candidate_features=actions,
                   candidate_mask=torch.tensor([[True, True, False]]))


def test_purchase_reaches_two_nobles_but_claims_only_one_and_respects_reply():
    batch = purchase_batch()
    relations, valid, summary, purchase = purchase_outcome_features(batch)
    fields = dict(zip(PURCHASE_SUMMARY_NAMES, summary[0, 0].tolist()))
    assert purchase.tolist() == [[True, False, False]]
    assert valid.tolist() == [[[True, True, False], [False]*3, [False]*3]]
    assert relations[0, 0, :2, -1].tolist() == [1, 1]
    assert fields["noble_points"] == 1 and fields["score_after"] == 1
    assert fields["new_final_round"] == fields["opponent_reply"] == 1
    assert fields["ends_now"] == 0
    assert fields["purchased_count_difference_after"] == pytest.approx(2/90)
    assert torch.isfinite(relations).all() and torch.isfinite(summary).all()
    assert summary[0, 1:].count_nonzero() == 0
    g = batch.global_features.clone()
    g[:, G.index("opponent_completed_turns_scaled")] = 21/40
    g[:, G.index("final_round_triggered")] = 1
    fields = dict(zip(PURCHASE_SUMMARY_NAMES, purchase_outcome_features(replace(batch, global_features=g))[2][0, 0].tolist()))
    assert fields["new_final_round"] == fields["opponent_reply"] == 0
    assert fields["ends_now"] == 1
    g[:, G.index("phase_main_action")] = 0
    g[:, G.index("phase_payment")] = 1
    assert not purchase_outcome_features(replace(batch, global_features=g))[3].any()


def test_noble_and_action_permutations_state_only_gradients_and_strict_checkpoint(tmp_path):
    batch = purchase_batch()
    torch.manual_seed(19)
    base = build_actor_critic({"architecture": "entity_attention_v1", "hidden": 16, "heads": 2,
        "layers": 1, "ffn_hidden": 32, "market_relations": True,
        "value_readout": "global_players_market", "purchase_outcomes": True})
    model = add_progress_head(base)
    for name, value in base.state_dict().items():
        torch.testing.assert_close(model.state_dict()[name], value, rtol=0, atol=0)
    reference = model(batch)
    changed = replace(batch, nobles=batch.nobles.flip(1), nobles_mask=batch.nobles_mask.flip(1))
    torch.testing.assert_close(model(changed)[0], reference[0])
    perm = torch.tensor([1, 0, 2])
    changed = replace(batch, candidate_features=batch.candidate_features[:, perm], candidate_mask=batch.candidate_mask[:, perm])
    torch.testing.assert_close(model(changed)[0], reference[0][:, perm])
    state = TorchStateBatch(**{k: getattr(batch, k) for k in TorchStateBatch.__dataclass_fields__})
    torch.testing.assert_close(model.value_from_state(state), reference[1])
    _, _, progress = model.forward_with_progress(batch)
    labels = (np.zeros((1, 2, 2), dtype=np.int8), np.zeros((1, 2, 2, 5), dtype=np.int8), np.ones(1, dtype=bool))
    sums = progress_loss_sums(progress, labels, torch.ones(1))
    (sums["progress_score_ce_sum"] + sums["progress_bonus_ce_sum"]).backward()
    assert model.context_encoder.weight.grad.abs().sum() > 0
    assert model.critic.network[1].weight.grad is None
    assert model.actor[1].weight.grad is None
    model.zero_grad(set_to_none=True)
    model(batch)[0][0, 0].backward()
    assert model.purchase_outcome_encoder.noble[0].weight.grad.abs().sum() > 0
    assert model.purchase_outcome_encoder.summary.weight.grad.abs().sum() > 0
    restored = build_actor_critic(asdict(model.config))
    restored.load_state_dict(model.state_dict(), strict=True)
    for expected, actual in zip(model(batch), restored(batch)):
        torch.testing.assert_close(expected, actual, rtol=0, atol=0)
    legacy = build_actor_critic({**asdict(base.config), "purchase_outcomes": False})
    with pytest.raises(RuntimeError):
        legacy.load_state_dict(model.state_dict(), strict=True)


def timeline(final_phase="payment"):
    # p0 buys on turn0; p1 buys on turn1. Each payment is a subdecision.
    players = np.array([0, 0, 1, 1])
    g = np.zeros((4, 148), dtype=np.float32)
    for i in (0, 2):
        g[i, G.index("phase_main_action")] = 1
    g[1, G.index("phase_payment")] = 1
    g[3, G.index("phase_" + final_phase)] = 1
    g[2:, G.index("opponent_score_scaled")] = 1/15
    g[2:, G.index("opponent_bonus_white_scaled")] = 1/18
    if final_phase == "choose_noble":
        g[3, G.index("self_score_scaled")] = 2/15
        g[3, G.index("self_bonus_blue_scaled")] = 1/18
    pending = np.zeros((4, 29), dtype=np.float32)
    pending[3, :2] = 1
    pending[3, 6] = 1  # blue bonus applied by the last Pay
    arrays = {"global_features": g, "player_id": players, "completed_player_turns": np.array([0, 0, 1, 1]),
              "pending_card": pending, "pending_card_mask": np.array([False, False, False, True])}
    return arrays, {"status": "natural_terminal", "terminal_result": {"scores": [1, 2 if final_phase == "payment" else 5], "completed_turns": [1, 1]}}


@pytest.mark.parametrize("phase", ["payment", "choose_noble"])
def test_progress_turn_units_perspective_terminal_purchase_and_noble(phase):
    arrays, meta = timeline(phase)
    labels = game_progress_targets(arrays, meta)
    assert labels["progress_mask"].tolist() == [True, False, True, False]
    score = 2 if phase == "payment" else 5
    np.testing.assert_array_equal(labels["progress_score"][0], [[1, score], [1, score]])
    np.testing.assert_array_equal(labels["progress_score"][2], [[score, 0], [score, 0]])
    np.testing.assert_array_equal(labels["progress_bonus"][0, 0], [[1, 0, 0, 0, 0], [0, 1, 0, 0, 0]])
    np.testing.assert_array_equal(labels["progress_bonus"][2, 0], [[0, 1, 0, 0, 0], [0]*5])
    # Final forced skips increase the clock but not the resources.
    meta["terminal_result"]["completed_turns"] = [2, 2]
    meta["terminal_result"]["reason"] = "consecutive_forced_skips"
    for key, value in game_progress_targets(arrays, meta).items():
        np.testing.assert_array_equal(value, labels[key])


def test_masked_progress_loss_has_no_gradient_and_outputs_are_averaged():
    logits = torch.zeros(2, 128, requires_grad=True)
    labels = (np.zeros((2, 2, 2), dtype=np.int8), np.zeros((2, 2, 2, 5), dtype=np.int8), np.array([True, False]))
    sums = progress_loss_sums(logits, labels, torch.ones(2))
    assert float(sums["progress_score_ce_sum"].detach()) == pytest.approx(np.log(17))
    assert float(sums["progress_bonus_ce_sum"].detach()) == pytest.approx(np.log(3))
    (sums["progress_score_ce_sum"] + sums["progress_bonus_ce_sum"]).backward()
    assert logits.grad[0].abs().sum() > 0 and logits.grad[1].abs().sum() == 0
    for weight in (-1, 0, float("nan"), True):
        with pytest.raises(ValueError):
            ProgressAuxiliaryConfig(loss_weight=weight)


@pytest.fixture
def config(tmp_path, az_runs, monkeypatch):
    import splendor.offline_objectives as entry
    monkeypatch.setattr(entry, "source_identity", lambda *_: {"test": True})
    _, first, second = az_runs
    index = build_replay_index([first, second], max_games=6, cache_bytes=64*1024**2)
    records = []
    for game in index.games:
        stat = game.path.stat()
        records.append({**asdict(game), "path": str(game.path), "size": stat.st_size,
                        "mtime_ns": stat.st_mtime_ns, "archive_sha256": sha256(game.path)})
    manifest = tmp_path / "manifest.jsonl"
    manifest.write_text("".join(json.dumps(r)+"\n" for r in records))
    n = sum(g.decision_count for g in index.split_games("train"))
    return FirstRoundOfflineConfig(manifest=str(manifest), manifest_sha256=sha256(manifest),
        model_config={"architecture": "entity_attention_v1", "hidden": 16, "heads": 2,
                      "layers": 1, "ffn_hidden": 32, "market_relations": True,
                      "value_readout": "global_players_market", "purchase_outcomes": True},
        first_round=1, last_round=2, expected_games_per_round=3, draw_exposures=3.5*4/n,
        cache_mib=64, validation_positions=8, validation_percent_step=50,
        progress_auxiliary=asdict(ProgressAuxiliaryConfig()),
        learner=LearnerConfig(device="cpu", batch_size=4, history_batch_size=2, validation_batch_size=16,
                              learning_rate=1e-4, checkpoint_every_steps=2))


def test_real_data_dual_sampler_cache_budget_resume_and_selection(config, tmp_path):
    full, resumed = tmp_path / "full", tmp_path / "resumed"
    index, pool, identity, fixed, plan = prepare_inputs(config, full)
    baseline = EarlyStoppingOfflineConfig.from_dict({k: v for k, v in asdict(config).items() if k != "progress_auxiliary"})
    bi, bp, _, bf, _ = prepare_mixed_inputs(baseline, tmp_path / "baseline")
    assert fixed == bf and plan["steps_target"] == 4
    new = make_batch_drawer(index, pool, 32)(DeterministicRng(192))
    old = make_batch_drawer(bi, bp, 32)(DeterministicRng(192))
    assert new.references == old.references
    assert all(s.arrays["policy_weight"][s.index] > 0 for s in new.samples)
    assert progress_targets(new.value_samples)[2].any()
    assert index.cache.bytes == sum(entry[2] for entry in index.cache._entries.values())
    for arrays, _, size in index.cache._entries.values():
        assert sum(a.nbytes for a in arrays.values()) == size
    initial = initialize_learner(config, identity, 4)
    assert plan["initialization"] == initial.parent_checkpoint
    run(config, full)
    run(config, resumed, max_steps_this_session=1)
    run(config, resumed)
    a, b = [load_alphazero_checkpoint(p / "checkpoints/final.pt") for p in (full, resumed)]
    assert a.sampling_rng_state == b.sampling_rng_state
    for key, value in a.model_state_dict.items():
        torch.testing.assert_close(value, b.model_state_dict[key], rtol=0, atol=0)
    for pid, state in a.optimizer_state_dict["state"].items():
        for key, value in state.items():
            torch.testing.assert_close(value, b.optimizer_state_dict["state"][pid][key], rtol=0, atol=0)
    metrics = [json.loads(line) for line in (full / "training_metrics.jsonl").read_text().splitlines()]
    updates = [m for m in metrics if m["event"] == "train_step"]
    assert all(m["policy_weight_sum"] == m["value_weight_sum"] == 4 for m in updates)
    for m in updates:
        assert m["total_loss"] == pytest.approx(m["policy_loss"] + m["value_loss"] + .05*m["progress_loss"], abs=1e-6)
    assert any(not torch.equal(value, initial.model.state_dict()[key]) for key, value in a.model_state_dict.items() if key.startswith("progress_head"))
    frozen = load_frozen_actor_critic_checkpoint(full / "checkpoints/final.pt")
    batch = collate_encoded_decisions([encode_decision(GameEngine.new(42).decision())])
    for x, y in zip(frozen(batch), a.build_model()(batch)):
        torch.testing.assert_close(x, y, rtol=0, atol=0)
    selected = select_checkpoint(config, full)
    assert read_json(full / "plan.json")["initialization"] == initial.parent_checkpoint
    row = read_json(full / "full_validation" / f"step-{selected['selected_step']:09d}.json")
    assert selected["selection_objective"] == pytest.approx(row["metrics"]["policy_kl"] + row["metrics"]["value_loss"])
    assert row["metrics"]["progress_positions"] > 0
    assert identity["progress_auxiliary"] == asdict(ProgressAuxiliaryConfig())
    with pytest.raises(ValueError, match="identical frozen"):
        run(replace(config, progress_auxiliary={"loss_weight": .1}), resumed)


def test_progress_disabled_uses_base_model_and_training_without_future_labels(config, tmp_path, monkeypatch):
    import splendor.offline_first_round as entry
    import splendor.progress_auxiliary as progress
    from splendor.offline_early_stopping import run as run_baseline
    from splendor.offline_scratch import initialize_learner as initialize_baseline

    def unexpected(*args, **kwargs):
        raise AssertionError("disabled progress must not build a head or derive future labels")

    monkeypatch.setattr(entry, "add_progress_head", unexpected)
    monkeypatch.setattr(progress, "game_progress_targets", unexpected)
    disabled = replace(config, progress_auxiliary=None)
    raw = {k: v for k, v in asdict(disabled).items() if k != "progress_auxiliary"}
    assert FirstRoundOfflineConfig.from_dict(raw).progress_auxiliary is None
    baseline = EarlyStoppingOfflineConfig.from_dict(raw)
    output = tmp_path / "disabled"
    index, pool, identity, fixed, plan = prepare_inputs(disabled, output)
    assert not index.cache.progress_targets
    assert "progress_auxiliary" not in identity
    samples = make_batch_drawer(index, pool, 4)(DeterministicRng(192)).value_samples
    assert all(not any(key.startswith("progress_") for key in s.arrays) for s in samples)
    learner = initialize_learner(disabled, identity, plan["steps_target"])
    reference = initialize_baseline(baseline, identity, plan["steps_target"])
    assert learner.model.config.architecture == "entity_attention_v1"
    assert learner.model.config.purchase_outcomes
    assert not hasattr(learner.model, "progress_head")
    assert plan["initialization"] == learner.parent_checkpoint
    assert learner.parent_checkpoint["auxiliary_seed"] is None
    for key, value in learner.model.state_dict().items():
        torch.testing.assert_close(value, reference.model.state_dict()[key], rtol=0, atol=0)

    run(disabled, output, max_steps_this_session=1)
    run(disabled, output)
    run_baseline(baseline, tmp_path / "baseline-disabled")
    actual = load_alphazero_checkpoint(output / "checkpoints/final.pt")
    expected = load_alphazero_checkpoint(tmp_path / "baseline-disabled/checkpoints/final.pt")
    assert actual.sampling_rng_state == expected.sampling_rng_state
    for key, value in actual.model_state_dict.items():
        torch.testing.assert_close(value, expected.model_state_dict[key], rtol=0, atol=0)
    for pid, state in actual.optimizer_state_dict["state"].items():
        for key, value in state.items():
            torch.testing.assert_close(value, expected.optimizer_state_dict["state"][pid][key], rtol=0, atol=0)
    rows = [json.loads(line) for line in (output / "training_metrics.jsonl").read_text().splitlines()]
    for row in (r for r in rows if r["event"] == "train_step"):
        assert "progress_loss" not in row
        assert row["total_loss"] == pytest.approx(row["policy_loss"] + row["value_loss"], abs=1e-6)
    selected = select_checkpoint(disabled, output)
    metrics = read_json(output / "full_validation" / f"step-{selected['selected_step']:09d}.json")["metrics"]
    assert "progress_loss" not in metrics
    with pytest.raises(ValueError, match="identical frozen"):
        run(config, output)
