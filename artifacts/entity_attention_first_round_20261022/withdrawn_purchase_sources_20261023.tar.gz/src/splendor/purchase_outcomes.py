"""Public, deterministic purchase-to-noble and end-of-turn relations.

Only MAIN_ACTION BuyMarket/BuyReserved candidates are supported. Payment and
other pending phases are deliberately masked: their state has different timing.
No refill, hidden card, future action, or payment preference is assumed.
"""
from __future__ import annotations

import torch
from torch import nn

from .features import ACTION_FEATURE_NAMES as A, GLOBAL_FEATURE_NAMES as G, SCALES

NOBLE_RELATION_DIM = 18  # requirement5, post-gap5, opponent-gap5, progress/eligible/newly-eligible
PURCHASE_SUMMARY_NAMES = (
    "card_points", "noble_points", "score_after", "reaches_threshold",
    "new_final_round", "ends_now", "opponent_reply", "purchased_count_difference_after",
)


def purchase_outcome_features(batch):
    raw = torch.where(batch.candidate_mask[..., None], batch.candidate_features, 0)
    g = batch.global_features
    purchase = (batch.candidate_mask & (g[:, G.index("phase_main_action"), None] > .5)
                & ((raw[..., A.index("type_buy_market")] > .5)
                   | (raw[..., A.index("type_buy_reserved")] > .5))
                & (raw[..., A.index("target_card.known")] > .5))
    bonus = (g[:, G.index("self_bonus_white_scaled"):G.index("self_bonus_white_scaled") + 5]
             * SCALES.player_bonus).round()
    color = raw[..., A.index("target_card.bonus_white"):A.index("target_card.bonus_white") + 5].round()
    nobles = torch.where(batch.nobles_mask[..., None], batch.nobles, 0)
    requirements = (nobles[..., 2:7] * SCALES.noble_requirement).round()
    before = (requirements - bonus[:, None, :]).clamp_min(0)
    after = (requirements[:, None, :, :] - bonus[:, None, None, :] - color[:, :, None, :]).clamp_min(0)
    eligible = (after.sum(-1) == 0) & batch.nobles_mask[:, None, :]
    newly = eligible & (before.sum(-1)[:, None, :] > 0)
    requirements = requirements[:, None].expand_as(after) / SCALES.noble_requirement
    opponent_gap = nobles[:, None, :, 12:17].expand_as(after)
    relations = torch.cat((requirements, after / SCALES.noble_requirement, opponent_gap,
                           (before[:, None].sum(-1) - after.sum(-1))[..., None],
                           eligible[..., None], newly[..., None]), dim=-1)
    valid = purchase[..., None] & batch.nobles_mask[:, None, :]
    relations = torch.where(valid[..., None], relations, 0)
    card_points = (raw[..., A.index("target_card.points_scaled")] * SCALES.card_points).round()
    # Current rules give every noble three points; max expresses the one-noble
    # limit and remains valid when several nobles qualify simultaneously.
    noble_points = torch.where(eligible, (nobles[:, None, :, 1] * SCALES.noble_points).round(), 0).amax(-1)
    score_after = (g[:, G.index("self_score_scaled"), None] * SCALES.player_score).round() + card_points + noble_points
    reaches = score_after >= 15
    already_final = g[:, G.index("final_round_triggered"), None] > .5
    final = already_final | reaches
    own_turns = (g[:, G.index("own_completed_turns_scaled"), None] * SCALES.completed_turns).round()
    other_turns = (g[:, G.index("opponent_completed_turns_scaled"), None] * SCALES.completed_turns).round()
    count_difference = ((g[:, G.index("self_purchased_cards_scaled"), None]
                         - g[:, G.index("opponent_purchased_cards_scaled"), None]) * SCALES.purchased_cards).round() + 1
    summary = torch.stack((card_points / SCALES.card_points, noble_points / SCALES.noble_points,
                           score_after / SCALES.player_score, reaches, reaches & ~already_final,
                           final & (own_turns + 1 == other_turns), final & (own_turns + 1 > other_turns),
                           count_difference.expand_as(score_after) / SCALES.purchased_cards), dim=-1)
    return relations, valid, torch.where(purchase[..., None], summary, 0), purchase


class PurchaseOutcomeEncoder(nn.Module):
    def __init__(self, hidden):
        super().__init__()
        self.noble = nn.Sequential(nn.Linear(NOBLE_RELATION_DIM, hidden), nn.GELU())
        self.summary = nn.Linear(len(PURCHASE_SUMMARY_NAMES), hidden, bias=False)

    def forward(self, batch):
        relations, valid, summary, purchase = purchase_outcome_features(batch)
        encoded = torch.where(valid[..., None], self.noble(relations), 0).sum(-2)
        encoded = encoded / valid.sum(-1, keepdim=True).clamp_min(1)
        return torch.where(purchase[..., None], encoded + self.summary(summary), 0)
