"""Purchase-outcome candidate with optional progress supervision; no arenas."""
from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
from pathlib import Path

import torch

from .actor_critic import build_actor_critic, model_config_from_dict
from .alphazero_recording import read_json, write_json
from .alphazero_train import AlphazeroLearner
from .offline_early_stopping import EarlyStoppingOfflineConfig
from .offline_mixed_budget import make_batch_drawer, prepare_inputs as prepare_mixed_inputs
from .offline_objectives import run as run_objectives
from .offline_scratch import select_checkpoint as select_scratch_checkpoint
from .progress_auxiliary import EntityAttentionProgressConfig, ProgressAuxiliaryConfig, add_progress_head
from .rng import DeterministicRng


@dataclass(frozen=True)
class FirstRoundOfflineConfig(EarlyStoppingOfflineConfig):
    progress_auxiliary: dict | None = None

    def __post_init__(self):
        super().__post_init__()
        if self.progress_auxiliary is not None:
            ProgressAuxiliaryConfig(**self.progress_auxiliary)
        if (self.model_config.get("architecture") != "entity_attention_v1"
                or self.model_config.get("purchase_outcomes") is not True):
            raise ValueError("first-round candidate requires attention with purchase_outcomes enabled")


def prepare_inputs(config, output):
    prepared = prepare_mixed_inputs(config, output)
    model_config = model_config_from_dict(config.model_config)
    if config.progress_auxiliary is not None:
        model_config = EntityAttentionProgressConfig(
            **(config.model_config | {"architecture": "entity_attention_progress_v1"}))
    prepared[-1]["initialization"].update(
        auxiliary_seed=(config.auxiliary_initialization_seed if config.progress_auxiliary is not None else None),
        model_config=asdict(model_config),
        optimizer="fresh AdamW")
    write_json(output / "plan.json", prepared[-1])
    return prepared


def select_checkpoint(config, output):
    return select_scratch_checkpoint(config, output, input_preparer=prepare_inputs)


def initialize_learner(config, identity, steps):
    torch.manual_seed(config.initialization_seed)
    base = build_actor_critic(config.model_config)
    model = base
    if config.progress_auxiliary is not None:
        torch.manual_seed(config.auxiliary_initialization_seed)
        model = add_progress_head(base)
    learner = AlphazeroLearner(model, config.learner, sampling_rng=DeterministicRng(config.sampling_seed))
    learner.replay_identity = identity
    learner.round_steps_target = steps
    learner.parent_checkpoint = {"kind": "random_initialization", "seed": config.initialization_seed,
        "auxiliary_seed": (config.auxiliary_initialization_seed if config.progress_auxiliary is not None else None),
        "model_config": asdict(model.config),
        "optimizer": "fresh AdamW"}
    return learner


def run(config, output, *, prepare_only=False, max_steps_this_session=None):
    return run_objectives(config, output, prepare_only=prepare_only,
        max_steps_this_session=max_steps_this_session, input_preparer=prepare_inputs,
        learner_initializer=initialize_learner, validation_percent_step=config.validation_percent_step,
        batch_drawer_factory=lambda index, value: make_batch_drawer(index, value, config.learner.batch_size),
        early_stopping_increases=config.early_stopping_increases)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--select-only", action="store_true")
    parser.add_argument("--max-steps-this-session", type=int)
    args = parser.parse_args()
    config = FirstRoundOfflineConfig.from_dict(read_json(args.config))
    if args.select_only:
        selected = select_checkpoint(config, args.output)
        print({"selected_step": selected["selected_step"], "objective": selected["selection_objective"]}, flush=True)
    else:
        run(config, args.output, prepare_only=args.prepare_only, max_steps_this_session=args.max_steps_this_session)
        if not args.prepare_only and read_json(args.output / "progress.json")["status"] == "complete":
            selected = select_checkpoint(config, args.output)
            print({"selected_step": selected["selected_step"], "objective": selected["selection_objective"]}, flush=True)


if __name__ == "__main__":
    main()
