#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
exec conda run --no-capture-output -n splendor env \
  PYTHONPATH=src OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
  TORCHINDUCTOR_COMPILE_THREADS=1 \
  python -u -m splendor.offline_first_round \
  --config configs/entity_attention_v1/offline_first_round_r21_r31_20261022.json \
  --output runs/entity_attention_purchase_only_r21_r31_20261023 "$@"
